({
    doInit: function(component, event, helper) {
        
    },

    doneRendering: function(cmp, event, helper) {
        // let urlArr = window.location.href.split('/');
        // if(urlArr.includes('explore-requests')) {
        //     document.getElementById('footer').style.display = 'none';
        // }
        // else {
        //     document.getElementById('footer').style.display = 'block';
        // } 

    },

    handleApplicationEvent : function(component, event, helper) {
        var showHeader = event.getParam("showHeader");
        var showFooter = event.getParam("showFooter");
        if(showHeader == false) {
            document.getElementById('header').style.display = 'none';
            document.getElementById('template-content').style.paddingTop = '0px';
        }
        else {
            document.getElementById('header').style.display = 'block';
            document.getElementById('template-content').style.paddingTop = '76px';
        }
        if(showFooter == false) {
            document.getElementById('footer').style.display = 'none';
        }
        else {
            document.getElementById('footer').style.display = 'block';
        } 
    },

    /* handleNotificationClick: function(component, event, helper) {
        let notificationId = event.currentTarget.dataset.id;
        // Implement your logic to navigate to the detail page of the notification.
        // For example, navigate to a record page:
        let navService = component.find("navService");
        let pageReference = {
            type: 'standard__recordPage',
            attributes: {
                recordId: notificationId,
                objectApiName: 'BusinessLicenseApplication', // replace with your actual object API name
                actionName: 'view'
            }
        };
        navService.navigate(pageReference);

        // Additionally, call markAsRead if needed
        // this.markAsRead(component, event, helper);
    }, */

    // handleNotificationClick: function(component, event, helper) {
    //     var notificationId = event.getSource().get("v.value");
        
    //     // Perform logic to get the target URL related to the notification
    //     var targetUrl = helper.getNotificationTargetUrl(notificationId);

    //     var urlEvent = $A.get("e.force:navigateToURL");
    //     urlEvent.setParams({
    //         "url": targetUrl
    //     });
    //     urlEvent.fire();
    // }

})