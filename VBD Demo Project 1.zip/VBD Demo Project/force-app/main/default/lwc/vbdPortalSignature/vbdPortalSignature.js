import { LightningElement, api,track} from 'lwc';
import currentUserSignature from '@salesforce/apex/VBD_PortalSignatureCtrl.currentUserSignature';
import updateFileTypeToSign from '@salesforce/apex/VBD_PortalSignatureCtrl.updateFileTypeToSign';
import saveSignature from '@salesforce/apex/VBD_PortalSignatureCtrl.saveSignature';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

let isMousePressed, 
    isDotFlag = false,
    
    prevX = 0,
    currX = 0,
    prevY = 0,
    currY = 0;            
   
let penColor = "#000000"; 
let lineWidth = 1.5;     

let canvasElement, ctx; 
let dataURL,convertedDataURI; //holds image data

export default class VbdPortalSignature extends LightningElement {
    @api recordId;
    showSignature = false;
    @api ContentVersionData;
    @api contentVersionId;
    fileName;
    @api headerText='Enter Your Signature';
    name;
    @track signText = '';
    isSpinner = false;
    currentUserSignatureId;
    currentSignatureVerId;
    newFileWasUploaded = false;
    uploadedFilesUrl = [];
    addEvents() {
        canvasElement.addEventListener('mousemove', this.handleMouseMove.bind(this));
        canvasElement.addEventListener('mousedown', this.handleMouseDown.bind(this));
        canvasElement.addEventListener('mouseup', this.handleMouseUp.bind(this));
        canvasElement.addEventListener('mouseout', this.handleMouseOut.bind(this));
        canvasElement.addEventListener("touchstart", this.handleTouchStart.bind(this));
        canvasElement.addEventListener("touchmove", this.handleTouchMove.bind(this));
        canvasElement.addEventListener("touchend", this.handleTouchEnd.bind(this));
    }

connectedCallback(){
    this.currentsignature();
}
currentsignature(){
    currentUserSignature({recordId: this.recordId})
        .then(result => {
            console.log('result',result);
            this.currentSignatureVerId = result;
            this.currentUserSignatureId = '/vbc/sfc/servlet.shepherd/version/download/'+result;
            this.showSignature = true;
            console.log('this.currentUserSignatureId',this.currentUserSignatureId);
        })
        .catch(error => {
            console.log('error',error);
            this.error = error;
        })
}

 @api 
 validateSign() {
    return (this.currentSignatureVerId != null);
 }

    handleReplaceClick() {
        this.showSignature = false;
    }

    get acceptedFormats() {
        return ['.jpg','.png', 'jpeg'];
    }
  
    async handleUploadFinished(event) {
        try {
            console.log('this.recordID', this.recordId);
            const uploadedFiles = event.detail.files;
            console.log('uploadedFiles',JSON.stringify(uploadedFiles))
        
            if(uploadedFiles && uploadedFiles.length > 0){
                console.log(uploadedFiles.length);
                this.newFileWasUploaded = true;
                console.log('uploadedFiles[0].contentVersionId',uploadedFiles[0].contentVersionId);
                console.log('uploadedFiles[0].contentDocumentId',uploadedFiles[0].contentDocumentId);
                const contV = await updateFileTypeToSign({contentVersionId:uploadedFiles[0].contentVersionId, contentDocId: uploadedFiles[0].contentDocumentId});
                console.log('contV--', contV);
                uploadedFiles.forEach(element => {
                    
                    this.uploadedFilesUrl.push({
                        id : '/sfc/servlet.shepherd/version/download/' + element.contentVersionId
                    })
                    console.log('this.uploadedFilesUrl',this.uploadedFilesUrl);
                    //location.reload();
                    this.currentsignature();
                });
            }
        } catch(e) {
            console.error('--e-', JSON.stringify(e));
        }
        
    }
   
     handleMouseMove(event){
        if (isMousePressed) {
            this.setupCoordinate(event);
            this.redraw();
        }     
    }    
    handleMouseDown(event){
        event.preventDefault();
        this.setupCoordinate(event);           
        isMousePressed = true;
        isDotFlag = true;
        if (isDotFlag) {
            this.drawDot();
            isDotFlag = false;
        }     
    }    
    handleMouseUp(event){
        isMousePressed = false;      
    }
    handleMouseOut(event){
        isMousePressed = false;      
    }
    handleTouchStart(event) {
        if (event.targetTouches.length == 1) {
            this.setupCoordinate(event);     
        }
    };

    handleTouchMove(event) {
        // Prevent scrolling.
        event.preventDefault();
        this.setupCoordinate(event);
        this.redraw();
    };
    handleTouchEnd(event) {
        var wasCanvasTouched = event.target === canvasElement;
        if (wasCanvasTouched) {
            event.preventDefault();
            this.setupCoordinate(event);
            this.redraw();
        }
    };
    renderedCallback() {
        if(this.template.querySelector('canvas')){
        canvasElement = this.template.querySelector('canvas');
        ctx = canvasElement.getContext("2d");
        ctx.lineCap = 'round';
        this.addEvents();
     }}
    signIt(e)
    {
        //var signText = e.detail.value;
        if(e.detail.value.length < this.signText.length){
            this.handleClearClick();
        }
        this.signText = e.detail.value;
        this.Signature=e.detail.value;
        ctx.font = "30px GreatVibes-Regular";
        ctx.fillText(e.detail.value, 30, canvasElement.height/2);
    }
    downloadSignature(e)
    {
        console.log('this.recordId',this.recordId);
        dataURL = canvasElement.toDataURL("image/jpg");
        this.downloadSign(e);
       
    }
    saveSignature(e)
    {
       
        try{
            ctx.globalCompositeOperation = "destination-over";
            ctx.fillStyle = "#FFF"; //white
            ctx.fillRect(0,0,canvasElement.width, canvasElement.height);
            dataURL = canvasElement.toDataURL("image/jpg");
        //convert that as base64 encoding
        convertedDataURI = dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
        console.log('convertedDataURI',JSON.stringify(convertedDataURI));
        this.ContentVersionData = convertedDataURI;
        console.log('this.ContentVersionData',JSON.stringify(this.ContentVersionData));
        console.log('this.recordID', this.recordId);
        this.isSpinner = true;
        saveSignature({ContentVersionData: convertedDataURI,recordId : this.recordId})
        .then(result => {
                // this.showSignature = true;
                this.contentVersionId = result;
                console.log('this.contentVersionId ', this.contentVersionId );
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Signature Saved Successfully',
                        variant: 'success',
                        
                    }),
                    
                );//location.reload();
                this.currentsignature();
           
        })
        .catch(error => {
            //show error message
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error uploading signature in Salesforce record',
                    message: error.body.message,
                    variant: 'error',
                }),
            );
        })
        .finally(() => {
            this.isSpinner = false;
        });
        }catch(error){
            console.log('error',error);
        }
        
    }
    downloadSign(e)
    {
        var link = document.createElement('a');
        link.download = '.jpg';
        link.href = dataURL;
        link.click();
    }
    handleClearClick()
    {
        this.signText= '';
        console.log('after clearbtn',this.signText);
        ctx.clearRect(0, 0, canvasElement.width, canvasElement.height);
    }

    setupCoordinate(eventParam){
        const clientRect = canvasElement.getBoundingClientRect();
        prevX = currX;
        prevY = currY;
        currX = eventParam.clientX -  clientRect.left;
        currY = eventParam.clientY - clientRect.top;
    }

    redraw() {
        ctx.beginPath();
        ctx.moveTo(prevX, prevY);
        ctx.lineTo(currX, currY);
        ctx.strokeStyle = penColor;
        ctx.lineWidth = lineWidth;        
        ctx.closePath(); 
        ctx.stroke(); 
    }
    drawDot(){
        ctx.beginPath();
        ctx.fillStyle = penColor;
        ctx.fillRect(currX, currY, lineWidth, lineWidth); 
        ctx.closePath();
    }
}