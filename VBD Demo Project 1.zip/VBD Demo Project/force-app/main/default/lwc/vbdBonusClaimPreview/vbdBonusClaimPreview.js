import { LightningElement, track } from 'lwc';
import Utility from 'c/utility';
import getBonusClaim from '@salesforce/apex/VBD_BonusClaimCreationCtrl.getBonusClaim';
import currentUserSignature from '@salesforce/apex/VBD_BonusClaimCreationCtrl.getSignature';
import saveBc from '@salesforce/apex/VBD_BonusClaimCreationCtrl.finalBcSave';
// import saveBonusClaimAsPdf from '@salesforce/apex/VBD_BonusClaimCreationCtrl.saveBonusClaimAsPdf';
import Id from '@salesforce/user/Id';
import getApplicantInforamtion from '@salesforce/apex/VBD_ApplicantInformationCtrl.getApplicantInforamtion';
import getAlternateConatct from '@salesforce/apex/VBD_ApplicantInformationCtrl.getAlternateConatct';
import getserviceHistoryDetails from '@salesforce/apex/VBD_ServiceHistoryPortalCtrl.getserviceHistoryDetails';
import sendingEmail from '@salesforce/apex/VBD_EmailAlertforPortalUser.sendingEmail';

let isDownFlag,
    isDotFlag = false,
    prevX = 0,
    currX = 0,
    prevY = 0,
    currY = 0;

let x = "#000000"; //blue color
let y = 1.5; //weight of line width and dot.       

let canvasElement, ctx; //storing canvas context
let attachment; //holds attachment information after saving the sigture on canvas
let dataURL, convertedDataURI; //holds image data
import saveSignature from '@salesforce/apex/VBD_BonusClaimCreationCtrl.saveSignature';

export default class VbdBonusClaimPreview extends Utility {
    @track showLoader;
    @track recordLocal = {};
    @track bounsName;
    @track showSignature = false;
    @track currentUserSignatureId;
    @track claimId;
    @track showCheckBox = false;
    @track showCheckBox2 = false;
    @track disableButton = true;

    @track userId = Id;
    @track alternateRecordData = {};
    @track selectedALternateContact;
    @track contactData = {};
    @track applicataRecData = {};
    @track showAlternateContact = false;
    @track serviceHistoryList1 = [];
    @track showTable = false;
    // @track claimId;
    initData() {
        this.showLoader = true;
        this.claimId = this.getURLParameter('claimId');
        this.getBounsCaimRecord();
        this.getApplicantData();
        this.getAalternateConatactData();
        this.getUserAccDetails();
    }


    @track serviceTypeOptions = [{ label: 'Active Duty', value: 'Active Duty' },
    { label: 'Deployed from Reserve', value: 'Deployed from Reserve' },
    { label: 'Deployed from National Guard', value: 'Deployed from National Guard' }];
    @track baseShipOptions = [{ label: 'Fort Bragg', value: 'Fort Bragg' },
    { label: 'Camp Pendleton', value: 'Camp Pendleton' },
    { label: 'USS Nimitz', value: 'USS Nimitz' },
    { label: 'Ramstein Air Base', value: 'Ramstein Air Base' },
    { label: 'Joint Base Pearl Harbor-Hickam', value: 'Joint Base Pearl Harbor-Hickam' }];
    @track countryBodyOptions = [{ label: 'Afghanistan', value: 'Afghanistan' },
    { label: 'Iraq', value: 'Iraq' },
    { label: 'Germany', value: 'Germany' },
    { label: 'South China Sea', value: 'South China Sea' },
    { label: 'Persian Gulf', value: 'Persian Gulf' }];

    async getBounsCaimRecord() {
        console.log('getBounsCaimRecord :---------1--------->' + this.claimId);

        await getBonusClaim({ recordId: this.claimId })
            .then(result => {
                console.log('result :-----> ' + JSON.stringify(result));
                this.recordLocal = result;
                this.bounsName = result.Bonus_Type__r.Name;
                this.showLoader = false;
            })
            .catch(error => {
                this.error = error;
                console.log('error--createBonusCalim-->' + JSON.stringify(this.error));
            })

    }

    get showSubmitbutton() {
        if (this.showCheckBox2 == true && this.showCheckBox == true) {
            return true;
        }
        return false;
    }

    redirectToJobLocationEdit() {
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("/s/"));
        window.location.href = baseURL + "/s/bonus-claim-creation?claimId=" + this.claimId;


    }

    redirectToApplicationInfoEdit() {
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("/s/"));
        window.location.href = baseURL + "/s/show-applicant-information?claimId=" + this.claimId;
    }

    redirectToServiceHistoryEdit() {
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("/s/"));
        window.location.href = baseURL + "/s/bonus-claim-service-history?claimId=" + this.claimId;
    }

    hanblesprevious() {
        this.redirectToCommunityCustomPage('bonus-claim-documentation', { 'claimId': this.claimId });
    }


    addEvents() {
        canvasElement.addEventListener('mousemove', this.handleMouseMove.bind(this));
        canvasElement.addEventListener('mousedown', this.handleMouseDown.bind(this));
        canvasElement.addEventListener('mouseup', this.handleMouseUp.bind(this));
        canvasElement.addEventListener('mouseout', this.handleMouseOut.bind(this));

    }

    // renderedCallback() {
    //     canvasElement = this.template.querySelector('canvas');
    //     ctx = canvasElement.getContext("2d");
    // }

    handleMouseMove(event) {
        console.log('handleMouseMove');
        this.searchCoordinatesForEvent('move', event);
    }

    handleMouseDown(event) {
        console.log('handleMouseDown');
        this.searchCoordinatesForEvent('down', event);
    }

    handleMouseUp(event) {
        console.log('handleMouseUp');
        this.searchCoordinatesForEvent('up', event);
    }

    handleMouseOut(event) {
        console.log('handleMouseOut');
        this.searchCoordinatesForEvent('out', event);
    }

    handleClearClick() {
        console.log('canvas element----', canvasElement);
        console.log('canvas ctx clear----', ctx);
        ctx.clearRect(0, 0, canvasElement.width, canvasElement.height);
    }

    searchCoordinatesForEvent(requestedEvent, event) {
        //event.preventDefault();
        if (requestedEvent === 'down') {
            this.setupCoordinate(event);
            isDownFlag = true;
            isDotFlag = true;
            if (isDotFlag) {
                this.drawDot();
                isDotFlag = false;
            }
        }
        if (requestedEvent === 'up' || requestedEvent === "out") {
            isDownFlag = false;
        }
        if (requestedEvent === 'move') {
            if (isDownFlag) {
                this.setupCoordinate(event);
                this.redraw();
            }
        }
    }

    //This method is primary called from mouse down & move to setup cordinates.
    setupCoordinate(eventParam) {
        //get size of an element and its position relative to the viewport 
        //using getBoundingClientRect which returns left, top, right, bottom, x, y, width, height.
        const clientRect = canvasElement.getBoundingClientRect();
        prevX = currX;
        prevY = currY;
        currX = eventParam.clientX - clientRect.left;
        currY = eventParam.clientY - clientRect.top;
    }

    //For every mouse move based on the coordinates line to redrawn
    redraw() {
        ctx.beginPath();
        ctx.moveTo(prevX, prevY);
        ctx.lineTo(currX, currY);
        ctx.strokeStyle = x; //sets the color, gradient and pattern of stroke
        ctx.lineWidth = y;
        ctx.closePath(); //create a path from current point to starting point
        ctx.stroke(); //draws the path
        console.log('redraw----ctx---', ctx);
    }

    //this draws the dot
    drawDot() {
        ctx.beginPath();
        ctx.fillStyle = x; //blue color
        ctx.fillRect(currX, currY, y, y); //fill rectrangle with coordinates
        ctx.closePath();
        console / log('draw-------,ctx');
    }

    renderedCallback() {
        this.template.querySelector('.path').setProgress();
        if (this.showCheckBox == true) {
            console.log('--renderedCallback->' + this.template.querySelector('canvas'));
            canvasElement = this.template.querySelector('canvas');
            ctx = canvasElement.getContext("2d");
            ctx.lineCap = 'round';
            this.addEvents();

        }



    }
    signIt(e) {
        var signText = e.detail.value;
        this.fileName = signText;
        ctx.font = "30px GreatVibes-Regular";
        this.handleClearClick(e);
        ctx.fillText(signText, 30, canvasElement.height / 2);
    }
    handleCheckBox(event) {
        this.showCheckBox = event.target.checked;
        console.log('showCheckBox----->' + event.target.value);
        console.log('showCheckBox----->' + this.showCheckBox);
    }
    handleCheckBox2(event) {
        this.showCheckBox2 = event.target.checked;
        // if (this.showCheckBox2 == false) {
        //     this.disableButton = true;
        // }
        // if (this.showCheckBox2 == true) {
        //     this.disableButton = false;

        // }
        console.log('showCheckBox2---1-->' + event.target.value);
        console.log('showCheckBox2----->' + this.showCheckBox2);
    }

    async sendEmail() {
        await sendingEmail({ recordid: this.claimId })
            .then(result => {
                console.log('Email Sent Successfully: ' + JSON.stringify(result));
            })
            .catch(error => {
                this.error = error;
                console.error('Error while sending email: ', JSON.stringify(this.error));
            });
    }


    hanbleContinue() {

        this.showSuccessNotification('Success', 'Your record has been submitted successfully');
        this.updateBonusClaim();
        
        // dataURL = canvasElement.toDataURL("image/jpg");
        // //convert that as base64 encoding
        // convertedDataURI = dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
        // console.log('convertedDataURI---->' + convertedDataURI);
        // if (convertedDataURI.length > 1309){
        //    // this.sendEmail();
        //     this.updateBonusClaim();
        //    // this.generateBonuClaimPDF();
        //     saveSignature({ signElement: convertedDataURI, recId: this.claimId })
        //         .then(result => {
        //             let saveSignature = result
        //         }).catch(error => {
        //             this.error = error;
        //             console.log('error---->' + JSON.stringify(this.error));
        //         })


            
        // } else {
        //     this.showErrorNotification('Error', 'Please sign your signature');
        // }
    }

    // async generateBonuClaimPDF() {
    //     await saveBonusClaimAsPdf({ recordId: this.claimId })
    //         .then(result => {

    //         }).catch(error => {
    //             this.error = error;
    //             console.log('error--PDF-->' + JSON.stringify(this.error));
    //         })

    // }
    async updateBonusClaim() {
        await saveBc({ bcRecordId: this.claimId })
            .then(result => {
                this.navigateRecordViewPage(this.claimId);
                console.log('result :-----> ' + result);
            })
            .catch(error => {
                this.error = error;
                console.log('error---->' + JSON.stringify(this.error));
            })

    }

    async getApplicantData() {
        await getApplicantInforamtion({ userId: this.userId })
            .then(result => {
                console.log('getApplicantData----result :-----> ' + JSON.stringify(result));
                this.applicataRecData = result;
                this.contactData = this.applicataRecData.Contacts[0];
                this.selectedALternateContact = this.applicataRecData.Do_you_want_to_add_an_alternate_contact__pc
                if (this.selectedALternateContact == 'Yes') {
                    this.showAlternateContact = true;
                }
                if (this.selectedALternateContact == 'No') {
                    this.showAlternateContact = false;
                }
                this.showLoader = false;
            })
            .catch(error => {
                this.error = error;
                console.log('getApplicantData--error-->' + JSON.stringify(this.error));
            })
    }

    async getAalternateConatactData() {
        await getAlternateConatct({ userId: this.userId })
            .then(result => {
                console.log('getAlternateConatct----result :-----> ' + JSON.stringify(result));
                this.alternateRecordData = result;

                this.showLoader = false;
            })
            .catch(error => {
                this.error = error;
                console.log('getApplicantData--error-->' + JSON.stringify(this.error));
            })
    }

    async getUserAccDetails() {
        await this.executeAction(getserviceHistoryDetails, {}, (response) => {
            // setTimeout(() => {
            console.log('response----' + JSON.stringify(response));
            console.log('response-1---' + JSON.stringify(response.ServiceHistoryList));
            this.serviceHistoryList1 = response.ServiceHistoryList
            this.contactId = response.ContactId[0];
            this.showLoader = false;
            this.showTable = true;
            // }, 3000);
            console.log('this.serviceHistoryList----' + JSON.stringify(this.serviceHistoryList1));
            console.log('this.contactId----' + JSON.stringify(this.contactId));
        }, (error) => {
            console.log('error----' + JSON.stringify(error));
        });
    }
}