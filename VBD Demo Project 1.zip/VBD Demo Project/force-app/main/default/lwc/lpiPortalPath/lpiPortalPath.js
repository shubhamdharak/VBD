import { LightningElement, api, track } from 'lwc';
import Utility from 'c/utility';
// import getreviewDetails from '@salesforce/apex/LPI_PortalReviewCtrl.getreviewDetails';
export default class LpiPortalPath extends Utility {

    // @api recordId;
    // @api record;
    @api currentStage;
    recordId;
    @api listOfStages = ['bonus-claim-information', 'application-information', 'service-history', 'documents', 'review'];

    connectedCallback() {
        this.recordId = this.getURLParameter('claimId');
        console.log('recordId-path---',JSON.stringify(this.recordId));
        // this.initData();
    }

    @api setProgress() {
        try{
            console.log('render---');
            if(this.currentStage != undefined) {
                for(let i=0; i< this.listOfStages.length; i++) {
                    if(this.listOfStages[i] == this.currentStage) {
                        this.template.querySelector('.' + this.currentStage).classList.add('slds-is-active');
                        this.template.querySelector('.' + this.currentStage).classList.remove('pending');
                        break;
                    }
                    else {
                        this.template.querySelector('.' + this.listOfStages[i]).classList.add('slds-is-completed');
                        this.template.querySelector('.' + this.listOfStages[i]).classList.remove('slds-is-active');
                        this.template.querySelector('.' + this.listOfStages[i]).classList.remove('pending');
                    }
                }        
            }
        }
        catch(e) {
            console.log('e----'+JSON.stringify(e));
            console.log('e----'+e);
        }
    }

    handleMarkerClick(event) {
        let page = event.target.dataset.id;
        console.log('event--page----',event.target.dataset.id);
        this.redirectToCommunityCustomPage(page, {'claimId': this.recordId});
    }
    
    initData() {
        // this.recordId = this.getURLParameter('recordId');
        
        // this.executeAction(getreviewDetails, {'recordId': this.recordId }, (response) => {
        //     // console.log('response-path---', response);
        //     // console.log('response1---path-', (JSON.stringify(response)));
        //     let data = JSON.parse(JSON.stringify(response));
        //     // console.log('data--path--', data.bla);
        //     // console.log('data1---path-', data.bla.LPI_Classification_of_Work__c);
        //     this.record.Account={};
        //     this.record = response.bla;
            
        //     this.accountInfo = JSON.parse(JSON.stringify(response.contactRecord)) ;
        //     if (response.bla.LPI_Contractor__r != null) {
        //         this.contractorInfo = JSON.parse(JSON.stringify(response.bla.LPI_Contractor__r));
        //     }
        //     /* // this.contractorInfo = JSON.parse(JSON.stringify(response.bla.LPI_Contractor__r));
        //     console.log(' this.contractorInfo----'+JSON.parse(JSON.stringify( this.contractorInfo)));
        //     console.log('response.bla.this.accountInfo----'+JSON.parse(JSON.stringify(this.accountInfo)));
            

        //     console.log('LPI_Classification_of_Work__c----', data.bla.LPI_Classification_of_Work__c);
        //     console.log('LPI_Project_Type__c----', data.bla.LPI_Project_Type__c);
        //     if (data.bla.LPI_Classification_of_Work__c === 'New' && data.bla.LPI_Project_Type__c === 'New Accessory Structure - detached (Garages/Carports/Sheds)') {
        //         this.isNewAcceStructure = true;
        //     }*/

        //     // console.log('LPI_Classification_of_Work__c--path--', data.bla.LPI_Classification_of_Work__c);
        //     // console.log('LPI_Project_Type__c--path--', data.bla.LPI_Project_Type__c);
        //     // if (data.bla.LPI_Classification_of_Work__c === 'New' && data.bla.LPI_Project_Type__c === 'New Duplex - Apartment building') {
        //     //     this.isNewDuplexFields = true;
        //     // }

        //     // this.fetchDocumentList();
            
        //     if (this.record.LPI_Classification_of_Work__c != undefined && this.record.LPI_Classification_of_Work__c != "") {
        //         this.handleClassChange(this.record.LPI_Classification_of_Work__c);
        //         this.isLoaded = true;
        //     }
           

        // },(error) => {
        //     console.log('error--path--', error);
        // });
    }

    handleClassChange(classOfWork) {
        //console.log('typeOfProjectData---path--:',this.typeOfProjectData);
        let key = this.typeOfProjectData.controllerValues[classOfWork];
        //console.log('key------path-:', key);
        this.typeOfProjectOptions = this.typeOfProjectData.values.filter(opt => opt.validFor.includes(key));
        //console.log('typeOfProjectOptions----path---:', this.typeOfProjectOptions);
        //console.log('JSON.stringify(this.typeOfProjectOptions) path--:', JSON.stringify(this.typeOfProjectOptions));
    }

    get disableLicensedProfessional(){
        return (this.record && this.record.LPI_Owner_Builder__c == "Yes" || this.record.LPI_Property_Owner__c == "Yes");
    }
    
}