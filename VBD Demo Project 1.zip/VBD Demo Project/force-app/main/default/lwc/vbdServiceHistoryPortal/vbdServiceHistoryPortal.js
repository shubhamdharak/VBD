import { LightningElement,track,wire } from 'lwc';
import Branch_of_Service__c from '@salesforce/schema/Service_History__c.Branch_of_Service__c';
import Character_of_Service__c from '@salesforce/schema/Service_History__c.Character_of_Service__c';
import Service_Grade__c from '@salesforce/schema/Service_History__c.Service_Grade__c';
import Type_of_Service__c from '@salesforce/schema/Service_History__c.Type_of_Service__c';
import Service_History__c from '@salesforce/schema/Service_History__c';
import {getPicklistValues } from "lightning/uiObjectInfoApi";
import {getObjectInfo} from 'lightning/uiObjectInfoApi';
import getserviceHistoryDetails from '@salesforce/apex/VBD_ServiceHistoryPortalCtrl.getserviceHistoryDetails';
import createServiceHistory from '@salesforce/apex/VBD_ServiceHistoryPortalCtrl.createServiceHistory';
import Utility from 'c/utility'; 

export default class VbdServiceHistoryPortal extends Utility {

    @track Type_of_Service_Option = [
        { label: 'Active Duty', value: 'Active Duty' },
        { label: 'Reserve', value: 'Reserve' },
        { label: 'National Guard', value: 'National Guard' }
    ];
    @track Service_Grade_Option = [  
        { label: 'E-1', value: 'E-1' },{ label: 'E-2', value: 'E-2' },{ label: 'E-3', value: 'E-3' },{ label: 'E-4', value: 'E-4' },
        { label: 'E-5', value: 'E-5' },{ label: 'E-6', value: 'E-6' },{ label: 'E-7', value: 'E-7' },{ label: 'E-8', value: 'E-8' },
        { label: 'E-9', value: 'E-9' },{ label: 'W-1', value: 'W-1' },{ label: 'W-2', value: 'W-2' },{ label: 'W-3', value: 'W-3' },
        { label: 'W-4', value: 'W-4' },{ label: 'W-5', value: 'W-5' },{ label: 'O-1', value: 'O-1' },{ label: 'O-2', value: 'O-2' },
        { label: 'O-3', value: 'O-3' },{ label: 'O-4', value: 'O-4' },{ label: 'O-5', value: 'O-5' },{ label: 'O-6', value: 'O-6' },
        { label: 'O-7', value: 'O-7' },{ label: 'O-8', value: 'O-8' },{ label: 'O-9', value: 'O-9' },{ label: 'O-10', value: 'O-10' },
        { label: 'O-11', value: 'O-11' }
    ];
    @track Character_of_Service_Option = [  
        { label: 'Honorable', value: 'Honorable' },
        { label: 'General Under Honorable', value: 'General Under Honorable' },
        { label: 'Other than Honorable', value: 'Other than Honorable' },
        { label: 'Bad Conduct Discharge', value: 'Bad Conduct Discharge' },
        { label: 'Dishonorable', value: 'Dishonorable' }
    ];
    @track BranchofServiceOption = [
        { label: 'U.S. Air Force', value: 'U.S. Air Force' },
        { label: 'U.S. Army', value: 'U.S. Army' },
        { label: 'U.S. Coast Guard', value: 'U.S. Coast Guard' },
        { label: 'U.S. Marine Corp', value: 'U.S. Marine Corp' },
        { label: 'U.S. Navy', value: 'U.S. Navy' },
        { label: 'U.S. Foreign Service', value: 'U.S. Foreign Service' },
        { label: 'U.S. Merchant Marine', value: 'U.S. Merchant Marine' }
    ];
    @track record = {};
    @track isShowModal = false;
    @track contactId = '';
    @track serviceHistoryList1=[];
    @track showLoader = false;
    @track showTable = false;
    @track dutyField = false;
    @track hideAddServiceHistoryButton = false;
    @track hideActionColumn = false;
     
    

    fieldChanged(event) {
        this.record[event.target.getAttribute('data-field')] = event.target.value;
        console.log('this.record-----'+JSON.stringify(this.record));
        console.log('this.record.Type_of_Service__c-----'+this.record.Type_of_Service__c);
        if(this.record.Type_of_Service__c == 'National Guard' || this.record.Type_of_Service__c == 'Reserve' || this.record.Type_of_Service__c == null || this.record.Type_of_Service__c == '' || this.record.Type_of_Service__c == undefined){
            this.dutyField = false;
        }else if (this.record.Type_of_Service__c == 'Active Duty'){
            this.dutyField = true;
        }
        console.log('this.dutyField-----'+this.dutyField);
}

    hideModalBox(){
        this.isShowModal = false;
        this.record = {};
        this.contactId = '';
        // this.BranchofServiceOption = [];
        // this.Character_of_Service_Option = [];
        // this.Service_Grade_Option = [];
        // this.Type_of_Service_Option = [];
    }

    handleClearContact(){
        this.record = {};
        // this.BranchofServiceOption = [];
        // this.Character_of_Service_Option = [];
        // this.Service_Grade_Option = [];
        // this.Type_of_Service_Option = [];
    }

    initData() {
        this.showLoader = true;
        this.getUserAccDetails();
        this.processParametersAfterS();
    }

    async processParametersAfterS() {
        const parametersAfterS = this.getParametersAfterS();
        console.log('Parameters after /s/:', parametersAfterS);
        if (parametersAfterS === undefined) {
            console.log('parametersAfterS is undefined--->');
            return;
        }else if (parametersAfterS.includes('bonus-claim/')) {
            this.hideAddServiceHistoryButton = true;
            this.hideActionColumn = true;
        }  else {
            console.log('No matching parameters found');
        }
    }

    getParametersAfterS() {
        const currentUrl = window.location.href;
        const splitUrl = currentUrl.split('/s/');
        if (splitUrl.length > 1) {
            return splitUrl[1];
        }
    }

    async getUserAccDetails(){
        await this.executeAction(getserviceHistoryDetails, {}, (response) => {
            // setTimeout(() => {
            console.log('response----'+ JSON.stringify(response));
            console.log('response-1---'+ JSON.stringify(response.ServiceHistoryList));
            this.serviceHistoryList1=response.ServiceHistoryList
                       this.contactId = response.ContactId[0];
            this.showLoader = false;
            this.showTable = true;
        // }, 3000);
            console.log('this.serviceHistoryList----'+ JSON.stringify(this.serviceHistoryList1));
            console.log('this.contactId----'+ JSON.stringify(this.contactId));
        }, (error) => {
            console.log('error----'+ JSON.stringify(error));
        });
    }

    handleContinue(){
        this.showLoader = true;
        let allValid = this.validateInputs();
        if(allValid){
            
            this.executeAction(createServiceHistory, {'contactId':  this.contactId, 'record': JSON.stringify(this.record)}, (response) => {
                console.log('response----', response);
                this.getUserAccDetails();
                this.hideModalBox();
                this.showLoader = false;

            }, (error) => {
                console.log('error----', error);
                this.showErrorNotification('Error', 'Something went wrong, please contact your administrator.');
                this.showLoader = false;
            });
        }
        else{
            this.showErrorNotification('Error', 'Please fill all required fields');
            this.showLoader = false;
        }
   
    }

    handleOpenModal(){
        this.isShowModal = true;
    }

    handleClick(event){
        this.record = {};
        const elementId = event.target.getAttribute('Id');
        this.record = {
            'Id': event.target.getAttribute('data-id'),
            'Date_of_Initial_Entry__c': event.target.getAttribute('data-entrydate'),
            'Date_of_Discharge__c': event.target.getAttribute('data-disdate'),
            'Branch_of_Service__c': event.target.getAttribute('data-branchserv'),
            'Service_Grade__c': event.target.getAttribute('data-grade'),
            'Character_of_Service__c': event.target.getAttribute('data-character'),
            'Type_of_Service__c': event.target.getAttribute('data-type'),
            'Date_of_Activation_Reserve_Guard__c': event.target.getAttribute('data-entrydateact'),
            'Date_Activation_Ended_Reserve_Guard__c': event.target.getAttribute('data-disdateact'),
        }        

        console.log('this.record handle click---------'+JSON.stringify(this.record));
        console.log('this.accountId------'+JSON.stringify(this.accountId));
        console.log('elementId---------'+elementId);
        this.handleOpenModal();    
    }

}