import { LightningElement, track } from 'lwc';
import Utility from 'c/utility';

export default class VBD_portalSearch extends Utility {

    @track showWelcomeText = false;

    pageURL = window.location.href;

    renderedCallback(){
        console.log(this.pageURL);
        if(this.pageURL === "https://st1741240594615.my.site.com/vbc/s/" || this.pageURL === "https://st1741240594615.my.site.com/vbc/s"){
            this.showWelcomeText = true;
        }
        else{ // don't need this but...
            this.showWelcomeText = false;
        }
    }

    handleSearchChange(event) {
        this.searchTerm = event.target.value;
    }

    handleGenericSearch() {
        this.redirectToCommunityCustomPage('general-search',{'searchTerm': this.searchTerm});
    }

    // handleAdvancedSearch() {
    //     this.redirectToCommunityCustomPage('general-search',{'showAdvancedSearch': true});
    // }
}