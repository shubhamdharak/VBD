import { LightningElement, track, wire } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import { CurrentPageReference } from "lightning/navigation";
import getAccountDetails from "@salesforce/apex/VBD_MyProfileController.getAccount";
import getserviceHistoryDetails from "@salesforce/apex/VBD_ServiceHistoryPortalCtrl.getserviceHistoryDetails";

export default class VBDHomePageProfileBanner extends NavigationMixin(LightningElement) {
   @track account = {};
   @track isLoading = true;
   renderComponent = false;
   currentPageReference = null;
   @track serviceHistoryList = [];

   /*******************************************************************************************
    * Method Name  : navigateToProfilePage
    * Description  :  This function is used to navigate to contact support page.
    * ******************************************************************************************/
   /*@wire(getAccountDetails)
    wiredAccount({ error, data }) {
        if (data) {            
            this.account = { ...data }; // Ensures reactivity
            this.fetchServiceHistory();
            this.isLoading = false;
        } else if (error) {
            this.error = error;
            console.log('Fetched error:', JSON.stringify(this.error));
            this.showToast('Error', 'Failed to fetch Account data', 'error');
        }
    }*/

   @wire(CurrentPageReference)
   getPageReferenceParameters(currentPageReference) {
      if (currentPageReference) {
         //console.log(JSON.stringify(currentPageReference));
         this.getAccountDetailsFromBackend();
      }
   }

   getAccountDetailsFromBackend() {
      getAccountDetails({})
         .then((result) => {
            this.account = { ...result }; // Ensures reactivity
            this.fetchServiceHistory();
            this.isLoading = false;
         })
         .catch((error) => {
            this.error = error;
            console.log("Fetched error:", JSON.stringify(this.error));
            this.showToast("Error", "Failed to fetch Account data", "error");
         });
   }

   /*******************************************************************************************
    * Method Name  : navigateToProfilePage
    * Description  :  This function is used to navigate to contact support page.
    * ******************************************************************************************/
   async fetchServiceHistory() {
      let response = await getserviceHistoryDetails({});
      this.serviceHistoryList = response.ServiceHistoryList;
      this.renderComponent = true;
   }
   /*******************************************************************************************
    * Method Name  : navigateToProfilePage
    * Description  :  This function is used to navigate to contact support page.
    * Author       : -Dayal
    * Created On   : 29-02-2024
    * Modification Log:
    ******************************************************************************************/
   navigateToProfilePage = () => {
      console.log("--------navigateToProfilePage---");
      try {
         this[NavigationMixin.Navigate]({
            type: "standard__webPage",
            attributes: {
               url: "/my-profile",
            },
         });
      } catch (error) {
         console.error("---------handleCheckout error---", JSON.stringify(error));
      }
   };

   /*******************************************************************************************
    * Method Name  : navigateToProfilePage
    * Description  :  This function is used to navigate to contact support page.
    * ******************************************************************************************/
   get isContactInfoFieldMissing() {
      console.log("isContactInfoFieldMissing===>");
      return !this.account || !this.account.FirstName || !this.account.LastName || !this.account.PersonEmail || !this.account.Phone || !this.account.SSN || !this.account.PersonGenderIdentity;
   }

   /*******************************************************************************************
    * Method Name  : navigateToProfilePage
    * Description  :  This function is used to navigate to contact support page.
    * ******************************************************************************************/
   get isAddressInfoMissing() {
      return !this.account || !this.account.MailingStreet || !this.account.MailingCity || !this.account.MailingState || !this.account.MailingPostalCode;
   }

   get getserviceHistoryList() {
      return this.serviceHistoryList.length > 0;
   }
   get getAllInfoAvailable() {
      return this.getserviceHistoryList && !this.isAddressInfoMissing && !this.isContactInfoFieldMissing;
   }
}