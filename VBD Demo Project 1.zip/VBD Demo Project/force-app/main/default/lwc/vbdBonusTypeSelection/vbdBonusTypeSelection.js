import { LightningElement,track } from 'lwc';
import getBounsTypes from '@salesforce/apex/VBD_BonusTypeSelectionCtrl.getBonusTypes';
import createBc from '@salesforce/apex/VBD_BonusClaimCreationCtrl.createBc';
import Utility from 'c/utility';
export default class VbdBonusTypeSelection extends Utility {
    @track allBounsType =[];
    @track selectedBounsType;
    @track bounsName;
    @track bonusTypesList;
    @track searchTerm = '';

    initData(){
        getBounsTypes()
        .then(result => {
            this.allBounsType = JSON.parse(JSON.stringify(result));
            this.bonusTypesList = JSON.parse(JSON.stringify(result));
           
            console.log('bouns Types:', JSON.stringify(this.allBounsType));
        })
        .catch(error => {
            console.error('Error fetching bouns types:', error);
        });
    }

    handleRadioChange(event) {       
        this.selectedBounsType = event.target.value;
        this.bounsName = event.target.label;
        console.log('selected value --->'+this.selectedBounsType);
        console.log('selected bounsName --->'+this.bounsName);
       
    }
    performSearch(event){
         try {
            this.searchTerm =event.target.value;
            console.log('searchTerm-->>'+this.searchTerm);
            let filteredArray = this.bonusTypesList.filter(item => item.Name.toLowerCase().includes(this.searchTerm.toLowerCase()));
            if (filteredArray.length === 0) {
                this.showErrorNotification('Error', 'No records found.')
            } else {
                this.allBounsType = filteredArray;
            }       
        }catch (error) {
            console.error('Error occurred during search:', error.message);

        }

    }

    handlePermitTypeSelection(){
        if(this.selectedBounsType !=null){
             createBc({ bonusType: this.selectedBounsType})
                .then(result => {
                    this.showLoader = false;
                    this.redirectToCommunityCustomPage('bonus-claim-creation',{'claimId':result.Id}); 
                })
                .catch(error => {
                    this.showLoader = false;
                    this.error = error;
                    console.log('error---->' + JSON.stringify(this.error));
                })

        }else{
             this.showNotification('Warning', 'Please Select the Bonus type.','Warning')

        }
        
    }
}