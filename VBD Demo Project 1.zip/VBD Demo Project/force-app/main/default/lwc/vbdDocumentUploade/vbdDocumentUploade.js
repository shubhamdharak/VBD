import { LightningElement, wire, track, api } from 'lwc';
import Utility from 'c/utility';
import Id from '@salesforce/user/Id';
import {NavigationMixin} from 'lightning/navigation'
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getDocumentTypes from '@salesforce/apex/VBD_DocumentUploadeCtrl.getDocumentType';
import documentUploads from '@salesforce/apex/VBD_DocumentUploadeCtrl.documentUploads';
import fetchDocuments from '@salesforce/apex/VBD_getUploadeDocumentWrapper.fetchDocuments';
import deleteDocument from '@salesforce/apex/VBD_DocumentUploadeCtrl.deleteDocument';
import checkIfPortalUser from '@salesforce/apex/VBD_DocumentUploadeCtrl.checkIfPortalUser';
import cloneDocuments from '@salesforce/apex/VBD_DocumentUploadeCtrl.cloneDocumentFromProfile';
import getBonusClaimDetail from '@salesforce/apex/VBD_DocumentUploadeCtrl.getBonusClaimDetail';

export default class VbdDocumentUploade extends Utility {
    @api recordId;
    //@track claimId;
    @track showLoader = false;
    userId = Id;
    isPortalUser = false;
    @track classificationOptions = []; 
    @track isModalOpen = false;
    @track recordLocal = {};
    @track fileIds = [];
    @track documentData = [];
    @track isRequired = [];
    @track classificationValue = '';
    @track documents = [];
    @track fileUploaded = false;
    @track attachDocModal = false;
    @track showAttachButton = false;
    @track selectedDocumentIds = [];
    @track selectedContentDocumentIds = [];
    @track documentDataContact = [];
    @track myProfilePage =false;
    @track hideNewButton = false;
    @track bonusClaimDetail;
    error;
        
    get optionsreq() {
        return [
            { label: 'Required', value: 'Required' },
            { label: 'Optional', value: 'Optional' },
        ];
    }

    get acceptedFormats() {
        return ['.pdf', '.png'];
    }

    connectedCallback() {
        console.log('##Inside Connected call Back--->');
        console.log('RecordId from URL:', this.recordId);
        this.getDocuments();
        this.checkPortalUser();
        this.processParametersAfterS();
    }

    async processParametersAfterS() {
        const parametersAfterS = this.getParametersAfterS();
        console.log('Parameters after /s/:', parametersAfterS);
        this.fetchDocumentsData();
        this.fetchDocumentsDataContact();
        if (parametersAfterS === undefined) {
            console.log('parametersAfterS is undefined--->');
            return;
        }else if (parametersAfterS.includes('bonus-claim-documentation')) {
            this.showAttachButton =true;
            this.recordId = new URL(window.location.href).searchParams.get('claimId');
            console.log('###this.recordId---->',this.recordId);
            this.fetchDocumentsData();
        } else if (parametersAfterS.includes('my-profile')) {
            this.fetchDocumentsData();
            this.myProfilePage = true;
        } else if (parametersAfterS.includes('bonus-claim-preview')) {
            this.hideNewButton = true;
        } else if (parametersAfterS.includes('bonus-claim')) {
            console.log('*****---->',this.recordId);
            if (this.recordId) {
                console.log('$$$---->');
                this.getBonusClaim();
            } else {
                console.log('this.recordId Not Found');
            }
        } else {
            console.log('No matching parameters found');
        }
    }

    getParametersAfterS() {
        const currentUrl = window.location.href;
        const splitUrl = currentUrl.split('/s/');
        if (splitUrl.length > 1) {
            return splitUrl[1];
        }
    }

    getBonusClaim() {
        console.log('$$@##',this.recordId);
        getBonusClaimDetail({ recordId: this.recordId })
        .then((data) => {
            //this.bonusClaimDetail =data;
            if (!!data && data === 'Awaiting Documentation') {
                this.hideNewButton = false; 
            } else {
                this.hideNewButton = true;
            }
        }) 
        .catch(error => {
            console.error('Error retrieving bonus claim:', error);
        });
    }


    fetchDocumentsData() {
        console.log('##Inside fetchDocuments--->');
        fetchDocuments({ recordId: this.recordId })
        .then((data) => {
            console.log('##fetchDocuments--->', data);
            this.documentData = data;
            console.log('##this.documentData--->', this.documentData);
        })
        .catch((error) => {
            console.error('Error fetching documents:', error);
        });
    }

    fetchDocumentsDataContact() {
        console.log('##Inside fetchDocumentsData for Contact --->');
        fetchDocuments({ recordId: null })
        .then((data) => {
            console.log('##fetch Documents Data Contact--->', data);
            this.documentDataContact = data;
            console.log('##this.documentDataContact--->', this.documentDataContact);
        })
        .catch((error) => {
            console.error('Error fetching documents:', error);
        });
    }

    checkPortalUser() {
        checkIfPortalUser()
        .then((result) => {
            this.isPortalUser = result;  
            console.log('Is Portal User:', this.isPortalUser); 
        })
        .catch((error) => {
            this.error = error;
            console.error('Error:', this.error); 
        });
    }

    openAttachDocModal() {
        console.log('##Inside openAttachDocModal--->');
        this.attachDocModal = true;
        const recordId = null;
        this.fetchDocumentsDataContact();
        console.log('##this.attachDocModal--->',this.attachDocModal);
    }

    handleAttachCloseModal() {
        this.attachDocModal = false;
    }

    handleCheckboxChange(event) {
        const documentId = event.target.dataset.docid; 
        const contentDocumentId = event.target.dataset.contentdocid; 
        const isChecked = event.target.checked;
        console.log('##docIdl--->',documentId);
        console.log('##isChecked--->',isChecked);
        console.log('##contentDocumentId--->',contentDocumentId);

        if (isChecked) {
            this.selectedDocumentIds.push(documentId);
            this.selectedContentDocumentIds.push(contentDocumentId);
        } else {
            this.selectedDocumentIds = this.selectedDocumentIds.filter(id => id !== documentId);
            this.selectedContentDocumentIds = this.selectedContentDocumentIds.filter(id => id !== contentDocumentId);
            console.log('$$this.selectedDocumentIds--->',JSON.stringify(this.selectedDocumentIds));
            console.log('$$this.selectedContentDocumentIds--->',JSON.stringify(this.selectedContentDocumentIds));
        }
    }

    async handleAttachDoc() {
        this.showLoader = true;
        console.log('##this.selectedDocumentIds--->',JSON.stringify(this.selectedDocumentIds));
        console.log('##this.selectedContentDocumentIds--->',JSON.stringify(this.selectedContentDocumentIds));

        if (this.selectedDocumentIds.length === 0) {
            this.showToast('Error', 'Please select at least one document to clone.', 'error');
            return;
        }

        await cloneDocuments({ documentId: this.selectedDocumentIds, ContentDocumentIds: this.selectedContentDocumentIds, claimId : this.recordId })
        .then(result => {
            console.log(result);
            this.showToast('Success', 'Documents attached successfully.', 'success');
            this.fetchDocumentsData();
            this.attachDocModal = false;
            this.showLoader = false;
        })
        .catch(error => {
            console.error(error);
            this.showToast('Error', 'Error cloning documents.', 'error');
            console.log('Error cloning documents: ' + error.body.message);
            this.showLoader = false;
        });
    }
    
    getDocuments() {
        console.log('##Inside getDocumentsk--->');
        getDocumentTypes()
        .then(result => {
            console.log('##getDocumentTypes--->',result);

            result.Documents.forEach(element => {
                this.classificationOptions.push({ label:element.Classification__c, value: element.Id, required: element.Required__c });
            });
            console.log('##classificationOptions--->', JSON.stringify(this.classificationOptions)); 
        })
        .catch(error => {
            console.log('##error--->',JSON.stringify(error));
        });
    }

    handleNewDocRecord(event) {
        console.log("event.target.value---.", event.target.value);
        this.recordLocal[event.target.getAttribute('data-field')] = event.target.value;

    }

    handlePreviewFileClick(event) {
        console.log("Event currentTarget: ", event.target.getAttribute("data-docid"));
        let docId = event.currentTarget.dataset.docid; 
        console.log("##docId---.", docId);
        let url = '';
        url = window.location.origin + '/vbc/sfc/servlet.shepherd/version/renditionDownload?rendition=THUMB720BY480&versionId=' + docId;
        this.navigateToWebPage(url);
    }

    handleDownloadFileClick(event){
        let docId = event.currentTarget.dataset.docid; 
        console.log("##docId---.", docId);
        let url = '';
        url = window.location.origin + '/vbc/sfc/servlet.shepherd/document/download/' + docId;
        console.log('url : ', url);
        this.navigateToWebPage(url);
    }

    handleDeleteFileClick(event) {
        const docId = event.currentTarget.dataset.docid;
        console.log('Deleting document with ID:', docId);

        deleteDocument({ documentId: docId })
            .then((result) => {
                this.showToast('Success', 'Document deleted successfully!', 'success');
                this.fetchDocumentsData();
            })
            .catch((error) => {
                this.showToast('Error', 'An error occurred while deleting the document.', 'error');
                console.error('Error in deleting document:', error);
            });
    }

    navigateToWebPage(url){
        this[NavigationMixin.Navigate]({
                type: 'standard__webPage',
                attributes: {
                    url: url
                }
            }, false 
        );
    }
    
    handleClassification(event){
        this.classificationValue = event.detail.value; 
        console.log('Selected Classification: ', this.classificationValue);
        this.classificationOptions.forEach(option => {
            console.log(`Label: ${option.label}, value: ${option.value}, Required: ${option.required}`);
        });

        const selectedOption = this.classificationOptions.find(option => option.value === this.classificationValue);
        if (selectedOption) {
            console.log('Selected Option Details:', JSON.stringify(selectedOption));
        }
    }

    handleUploadFinished(event) {
        const uploadedFiles = event.detail.files;
        console.log('##uploadedFiles ', uploadedFiles);
        if (uploadedFiles.length > 0) {
            this.fileUploaded = true;
        } else {
            this.fileUploaded = false;
        }
        for (let i = 0; i < uploadedFiles.length; i++) {
            this.fileIds.push(uploadedFiles[i].contentVersionId);
            console.log('#fileIds', this.fileIds);
        }
        
    }

    createNewDoc(event) {
        this.isModalOpen = true;
        console.log('isModalOpen', this.isModalOpen);
    }

    async handleSave(event) {
        this.showLoader = true;
        console.log('Inside handleSave');
        console.log('FileIds:', JSON.stringify(this.fileIds));
        console.log('Classification Value:', this.classificationValue);
        console.log('claimId:', this.recordId);


        if (!this.fileUploaded || !this.validateInputs()) {
            this.showToast('Error', 'Please complete all required fields', 'error');
            return;
        }
    
        try {
            const response = await documentUploads({
                fileIds: this.fileIds,
                documentTypeId: this.classificationValue,
                claimId : this.recordId
            });
    
            console.log('Response received:', response);
            this.showToast('Success', 'Documents uploaded successfully.', 'success');
            this.fetchDocumentsData();
            this.isModalOpen = false;
            this.showLoader = false;

        } catch (error) {
            console.error('Error during document upload action:', error);
            this.showToast('Error', 'There was an error during the document upload process.', 'error');
            this.showLoader = false;

        }
    }
    
    validateInputs() {
        return [...this.template.querySelectorAll('.input')].every(inputCmp => {
            inputCmp.reportValidity();
            return inputCmp.checkValidity();
        });
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: variant, 
                mode: 'dismissable',
            })
        );
    }
    
    handleClose() {
        this.isModalOpen = false;
    }

}