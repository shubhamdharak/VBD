import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
/**
 * Created by Pankaj on 07-02-2021.
 */

import { api, LightningElement, track, wire } from 'lwc';

export default class Utility extends NavigationMixin(LightningElement) {
    // record passed from parent component. It is optional.
    @api record = {};
    // use this variable to bind in components
    @track recordLocal = {};
    @track txtAreaChar = 2000;
    @track txtAreaCharSuspectCombination = 2000;
    @track txtAreaCharSuspectAddInfo = 2000;
    @track txtAreaCharEmployer = 2000;

    // add loading html if we want to add loading icons
    showLoader = false;

    skipInputFieldValidation = false;
    skipCustomLogicValidation = false;

    hasInitiated = false;
    /*
     * InitData method creation to work like connectedCallback()
     */
    connectedCallback() {
        //this.orderDetail = this.orderDetailUsingParameter.clone();
        if (this.hasInitiated == false) {
            //read page params
            let testURL = window.location.href;
            let newURL = new URL(testURL).searchParams;
            this.topicId = newURL.get('id');

            this.hasInitiated = true;
            this.initializeRecordVariable();
            if (this.initData) {
                this.initData();
            }
        }
        if (this.handledOnLoadCallBack) {
            this.handledOnLoadCallBack();
        }

    }

    /*
     * Get URL parameter
     */
    getURLParameter(paramName) {
        return ((new URL(window.location.href)).searchParams.get(paramName))
    }

    /*
     * Initializes record variable
     */
    initializeRecordVariable() {
        if (this.record != undefined) {
            this.recordLocal = JSON.parse(JSON.stringify(this.record));
        }
    }

    /*
     * Sets input value
     */
    fieldChanged(event) {
        let fieldAPIName = event.target.getAttribute('data-field');
        if (fieldAPIName.indexOf('.') > -1) {
            let fieldArr = fieldAPIName.split('.');
            let objectToUpdate = this.recordLocal;
            for (let i = 0; i < (fieldArr.length - 1); i++) {
                objectToUpdate = objectToUpdate[fieldArr[i]];
            }
            let apiName = fieldArr[fieldArr.length - 1];
            objectToUpdate[apiName] = event.target.value;
        } else {
            this.recordLocal[fieldAPIName] = event.target.value;
        }

    }

    /*
     * Sets checkbox value
     */
    fieldChecked(event) {
        this.recordLocal[event.target.getAttribute('data-field')] = event.target.checked;
    }

    allInputsValidated = true;

    /*
     * Gets value from recordLocal variable
     */
    @api
    getRecordDetails() {
        //console.log(' getRecordDetails---');
        if (this.updateRecordLocal) {
            this.updateRecordLocal();
        }
        let allInputFieldValid = true;
        if (this.skipInputFieldValidation == false) {
            allInputFieldValid = this.validateInputs();
        }

        let customLogicValid = true;
        if (this.skipCustomLogicValidation == false && this.validateCustomInput) {
            customLogicValid = this.validateCustomInput();
        }

        if (allInputFieldValid == false || customLogicValid == false) {
            return undefined;
        }

        if (this.allInputsValidated == false) {
            return undefined;
        }
        //console.log(' this.recordLocal---');
        //console.log(this.recordLocal);
        return this.recordLocal;
    }

    handleTextAreaKeyUp(event) {
        let txtval = event.target.value;
        console.log(txtval);
        var txtlen = txtval.length;
        this.txtAreaChar = 2000 - txtlen;
    }

    handleCapitalize(event) {
        var str = event.target.value;
        console.log("Inside capitalize");
        if (typeof str !== 'string') {
            return;
        }
        console.log(str);
        var capVal = str.charAt(0).toUpperCase() + str.slice(1);
        console.log(capVal);
        console.log("IcapVal");
        event.target.value = capVal;
        console.log(event.target.value);
        this.fieldChanged(event);
        return capVal;
    }

    handlekeychange(event) {
        console.log('## inside handlekeychange');
        console.log(event);
        console.log(event.keyCode);
        if (event.keyCode === 8 || event.keyCode === 46) {
            console.log('## inside if condition');
            event.preventDefault();
        }
    }
    findUnique(str) {

        // Split the string to make array
        str = str.split("")

        // Create a set using array
        str = new Set(str);

        // Conver the set into array using spread
        // operator and join it to make string
        str = [...str].join("");
        console.log('str---', str);
        return str;
    }
    handlePhoneValidation(event) {
        try {
            //let number = this.recordLocal.Victim_Contact__r.Phone;
            //let inputCmp = this.template.querySelector('.phoneField');
            // let number   = inputCmp.value;
            let allValidPhone = true;
            let number = event.target.value;
            console.log('## inside handlePhoneValidation---', value);
            console.log('## inside ---', event.target.className);
            
            var classes = event.target.className;
            let inputCmp;
            if (classes.includes("phoneField2")) {
                inputCmp = this.template.querySelector('.phoneField2');
            } else {
                inputCmp = this.template.querySelector('.phoneField');
            }

            if (number && number !== null && number !== '') {
                let cleanedNumber = ('' + number).replace(/\D/g, '');
                let phoneNumber = cleanedNumber.match(/^(\d{3})(\d{3})(\d{4})$/);
                let newNumber = '';
                let allowedPhoneNumber = cleanedNumber.match(/((\d)\2{4,})|(0123456789)|(9876543210)|(0|1)\d{9}|(1234567890)/g);
                console.log('allowedPhoneNumber---', allowedPhoneNumber);

                if (phoneNumber) {
                    newNumber = '(' + phoneNumber[1] + ') ' + phoneNumber[2] + '-' + phoneNumber[3];
                    console.log('newNumber', newNumber);
                    event.target.value = newNumber;
                }
                

                var value = event.target.value;
                console.log('value---', value);
                if (value != newNumber) {
                    allValidPhone = false;
                    inputCmp.setCustomValidity("Phone number must begin with a 3 digit area code followed by a 7 digit number.");
                } else if (allowedPhoneNumber) {
                    console.log('allowedPhoneNumber!!!---', allowedPhoneNumber);
                    allValidPhone = false;
                    inputCmp.setCustomValidity("Phone number must begin with a 3 digit area code followed by a 7 digit number.");
                } /*else if (this.findUnique(cleanedNumber).length <= 3) {
                    console.log('this.findUnique(cleanedNumber).length!!!---', this.findUnique(cleanedNumber).length);
                    allValidPhone = false;
                    inputCmp.setCustomValidity("Phone number must begin with a 3 digit area code followed by a 7 digit number.");
                } */else {
                    inputCmp.setCustomValidity(""); // if there was a custom error before, reset it
                }
                inputCmp.reportValidity(); // Tells lightning:input to show the error right away without needing interaction
            } else {
                console.log('else--here-');
                inputCmp.setCustomValidity(""); // if there was a custom error before, reset it
                inputCmp.reportValidity();
            }
            return allValidPhone;
        } catch (e) {
            console.log(e);
        }
    }


    //methodToValidateBirthdate
    validateBirthDate() {
        let bDateValid = true;
        let inputCmp = this.template.querySelector('.birthdate');
        console.log('Inside Birthdate validateion: ');
        console.log(inputCmp);
        console.log(inputCmp.value);
        if (inputCmp.value) {
            console.log("Inside if 1");
            /*var pattrn = new RegExp("^(1[0-2]|0[1-9])\/(3[01]|[12][0-9]|0[1-9])\/[0-9]{4}$");
            var res = pattrn.test(inputCmp.value);
            console.log("res:  "+ res);
            if(!res){
                inputCmp.setCustomValidity("Pattern Change date format");
            }*/
            let bDateMs = Date.parse(inputCmp.value);
            let currentDate = new Date();
            console.log("Inside current date");
            console.log(currentDate.getTime());
            console.log("Inside birth date");
            console.log(bDateMs);

            if (bDateMs > currentDate.getTime()) {
                console.log("Inside if 2");
                //inputCmp.setCustomValidity("Birth Date should be a date in the past");
                inputCmp.setCustomValidity("Please enter date as mm/dd/yyyy. Date of birth must be in the past and cannot be more than 100 years in the past");
                bDateValid = false;
            } else if (bDateMs < 0) {
                //logic to calculate 100 years differenece
                let multiplier = 1000 * 60 * 60 * 24 * 365;
                //let isDiff100yrs = false;
                console.log("Inside multiplier");
                console.log(multiplier);
                let secondsPassed = currentDate.getTime() + (bDateMs * -1);
                console.log("secondsPassed");
                console.log(secondsPassed);
                let years = Math.round(secondsPassed / multiplier);
                console.log("years");
                console.log(years);
                if (years > 100) {
                    bDateValid = false
                    inputCmp.setCustomValidity("Please enter date as mm/dd/yyyy. Date of birth must be in the past and cannot be more than 100 years in the past");
                }

            }

            if (bDateValid == true) {
                inputCmp.setCustomValidity("");
            }
        }
        inputCmp.reportValidity();
        return bDateValid;
    }

    //method to handle text area validation
    handleTextAreaValidation(event) {
        let validField = true;
        console.log("# handle text area Event ");
        let inputCmp = this.template.querySelector('.txtArea');
        let txtArea = inputCmp.value;
        console.log(txtArea);
        let expr = "^[a-zA-Z0-9.#,()\/\- , . ? ' ; : ! @ # $ % & * ( ) - _ = + ]*$";
        console.log("before");
        let result = txtArea.match(/^[a-zA-Z0-9.#,()\/\- , . ? ' ; : ! @ # $ % & * ( ) - _ = + \n]*$/);
        console.log("dev");
        console.log(result);
        if (result == null) {
            inputCmp.setCustomValidity("Additional information is required and may only contain letters, numbers, and the following: , . ? / ' ; : ! @ # $ % & * ( ) - _ = +");
            validField = false;
        } else {
            inputCmp.setCustomValidity("");
        }
        inputCmp.reportValidity();
        return validField;
    }

    //method to validate email
    validateEmail() {
        let emailValid = true;
        let inputCmp = this.template.querySelector('[data-id="confirmEmailField"]');
        let confEmail = inputCmp.value;

        if (this.recordLocal.Contact.Email != confEmail) {
            inputCmp.setCustomValidity("Email address does not match");
            emailValid = false;
        } else {
            inputCmp.setCustomValidity("");
            emailValid = true;
        }
        inputCmp.reportValidity();
        return emailValid;
    }

    validateBusinessAccount() {

        let isBAccNameProvided = false;
        console.log("## handle businessaccount blur");
        let inputCmp = this.template.querySelectorAll('.isBusinessAcc');

        let bAccName = this.recordLocal.Account.Name;
        // adding this to handle suspect account
        if (!bAccName || bAccName == '' || typeof bAccName == 'undefined') {
            console.log("## handle suspect handler businessaccount blur");
            bAccName = this.recordLocal.Employers_Name__r.Name;
        }
        console.log('bAccName : ', bAccName);
        if (!bAccName || bAccName == '' || typeof bAccName == 'undefined') {
            inputCmp.forEach(inpCmp => {
                if (inpCmp.label && inpCmp.label !== 'State') {
                    console.log("Value");
                    console.log(inpCmp.value);
                    if (inpCmp.value && inpCmp.value !== '') {
                        console.log('INSIDE ERROR : ', inpCmp);
                        inpCmp.setCustomValidity("PLEASE PROVIDE EMPLOYER NAME FIRST");
                        inpCmp.reportValidity();
                    } else {
                        inpCmp.setCustomValidity("");
                        inpCmp.reportValidity();
                    }
                }
            });
        } else {
            isBAccNameProvided = true;
            inputCmp.forEach(inpCmp => {
                inpCmp.setCustomValidity("");
            });
        }
        inputCmp.reportValidity();

        return isBAccNameProvided;
    }

    handleEmailBlur() {
        console.log("## inside handle email blur");

        let emailFieldCmp = this.template.querySelector('.emailField');
        console.log(emailFieldCmp.value);
        let mailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        let emailAddress = emailFieldCmp.value; // this.accountRecordLocal.PersonEmail;
        let allValid = true;
        if (emailAddress !== null && emailAddress !== '') {
            let mailMatcher = mailRegex.test(emailAddress);
            if (mailMatcher == false) {
                allValid = false;
                console.log("## 2 handle emial blur");
                emailFieldCmp.setCustomValidity('E-mail address must contain the username followed by @ followed by the domain name (e.g. username@edd.ca.gov)');
            } else {
                emailFieldCmp.setCustomValidity('');
            }
            console.log("## handendle emial blur");
            emailFieldCmp.reportValidity();
        }
        return allValid;
    }

    /*
     * Setter method to set record local
     */
    @api
    setRecordDetails(recordLocal) {
        this.recordLocal = recordLocal;
    }

    /*
     * Skips all validation
     */
    @api
    skipAllValidations() {
        this.skipInputFieldValidation = true;
        this.skipCustomLogicValidation = true;
    }

    /*
     * Enables validation
     */
    @api
    enableAllValidations() {
        this.skipInputFieldValidation = false;
        this.skipCustomLogicValidation = false;
    }

    /*
     * Skips input validation
     */
    @api
    skipInputValidations() {
        this.skipInputFieldValidation = true;;
    }

    /*
     * Enables input validation
     */
    @api
    enableInputValidations() {
        this.skipInputFieldValidation = false;
    }

    /*
     * Skips custom validation
     */
    @api
    skipCustomValidations() {
        this.skipCustomLogicValidation = true;;
    }

    /*
     * Enables custom validation
     */
    @api
    enableCustomValidations() {
        this.skipCustomLogicValidation = false;
    }

    /*
     * Redirect to community home page
     */
    redirectToCommunityHome = () => {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                name: 'Home'
            }
        });
    }

    /*
     * Redirect to custom community page
     */
    redirectToCommunityCustomPage = (namedPage, stateJSON) => {

        console.log("inside nav" + namedPage);
        console.log("stateJSON" + stateJSON);
        //https://developer.salesforce.com/docs/component-library/documentation/en/lwc/lwc.reference_page_reference_type
        if (stateJSON == undefined) {
            stateJSON = {};
        }
        console.log("inside nav2 " + namedPage);
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: namedPage,
            },
            state: stateJSON
        });
    }

    /*
     * Log out community user and redirect to login page
     */
    logoutCommunityUser = () => {
        this[NavigationMixin.Navigate]({
            type: 'comm__loginPage',
            attributes: {
                actionName: 'logout'
            }
        });
    }

    /*
     * Redirect to login page
     */
    redirectToCommunityLoginPage = () => {
        this[NavigationMixin.Navigate]({
            type: 'comm__loginPage',
            attributes: {
                actionName: 'login'
            }
        });
    }

    /*
     * Redirect to record page
     */
    navigateRecordViewPage = (recordId) => {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: recordId,
                actionName: 'view'
            }
        });
    }
    /*
     * Redirect to record page in new tab
     */
    navigateRecordInNewTab = (recordId, objApiName, actionName) => {
        console.log('recordId---', recordId);
        console.log('objApiName---', objApiName);
        console.log('actionName---', actionName);
        this[NavigationMixin.GenerateUrl]({
            type: "standard__recordPage",
            attributes: {
                recordId: recordId,
                objectApiName: objApiName,
                actionName: actionName
            }
        }).then(url => {
            console.log('url---', url);
            window.open(url, "_blank");
        })
    }
    /*
     * Redirect to List view
     */
    navigateToObjectListView = (objectApiName) => {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: objectApiName,
                actionName: 'list'
            },
            state: {
                filterName: 'Recent'
            },
        });
    }

    /*
     * Show custom toast
     */
    showNotification = (_title, _message, _variant, _mode) => {
        const evt = new ShowToastEvent({
            title: _title,
            message: _message,
            variant: _variant,
            mode: _mode
        });
        this.dispatchEvent(evt);
    };

    /*
     * Show success toast
     */
    showSuccessNotification = (_title, _message) => {
        const evt = new ShowToastEvent({
            title: _title,
            message: _message,
            variant: 'success',
        });
        this.dispatchEvent(evt);
    };

    /*
     * Show error toast
     */
    showErrorNotification = (_title, _message) => {
        const evt = new ShowToastEvent({
            title: _title,
            message: _message,
            variant: 'error',
        });
        this.dispatchEvent(evt);
    };

    /*
     * Used to get data from apex
     */
    executeAction = (method, params, onSuccess, onError) => {
        this.showLoader = true;
        method(params)
            .then(response => {
                this.showLoader = false;
                onSuccess(response);
            }).catch(error => {
                this.showLoader = false;
                if (onError) {
                    onError(error);
                } else {
                    console.log("Error Occuredwhile calling apex");;
                    console.log(error);
                    let errorMessage = error.body && error.body.message ? error.body.message : 'Something went wrong, please contact your administrator.';
                    console.error('Method ' + errorMessage);
                    this.showNotification('Error', errorMessage, 'error');
                }
            });
    };

    /*
     * Validate input fields which has class input
     */
    validateInputs() {
        const allValid = [...this.template.querySelectorAll('.input')]
            .reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);
        return allValid;
    }

    /*
     * Sets field null
     */
    setFieldsToBlank(field) {
        this.recordLocal[field] = null;
    }

    triggerHeaderFooterEvent(showHeader, showFooter) {
        const headerFooterEvent = new CustomEvent('headerfooterevent', { detail: { 'showHeader': showHeader, 'showFooter': showFooter }, bubbles: true });
        this.dispatchEvent(headerFooterEvent);
    }
}