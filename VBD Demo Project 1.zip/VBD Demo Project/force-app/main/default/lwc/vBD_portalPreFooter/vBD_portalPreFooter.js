import { LightningElement } from 'lwc';
import logoPath from '@salesforce/resourceUrl/VBD_portalHeaderlogo';

export default class vBD_portalPreFooter extends LightningElement {
   spokaneLogo = logoPath;
}