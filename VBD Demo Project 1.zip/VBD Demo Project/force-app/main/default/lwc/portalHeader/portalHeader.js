import { LightningElement, track, wire } from 'lwc';
// import logoPath from '@salesforce/resourceUrl/spokaneportalresources';
import Id from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
import UserNameFld from '@salesforce/schema/User.Name';
import userEmailFld from '@salesforce/schema/User.Email';
import userIsActiveFld from '@salesforce/schema/User.IsActive';
import userAliasFld from '@salesforce/schema/User.Alias';
import Utility from 'c/utility';
export default class PortalHeader extends Utility {
    userId = Id;
    clickedButtonLabel;
    // spokaneLogo = logoPath +'/santa-Clara-logo.svg';
    // dehLogo = logoPath +'/deh-logo.svg';
    @track userRecord = {};
    @track isLoggedInUser = false;

    connectedCallback(){
        if(this.userId != undefined) {
            this.isLoggedInUser = true;
        }
    }


    handleClick(event) {
        this.clickedButtonLabel = event.target.label;
    }

    @wire(getRecord, { recordId: Id, fields: [UserNameFld, userEmailFld, userIsActiveFld, userAliasFld ]}) 
    userDetails({error, data}) {
        if (data) {
            this.userRecord.Name = data.fields.Name.value;
            this.userRecord.Email = data.fields.Email.value;
            this.userRecord.Id = this.userId;
        } else if (error) {
            console.log('error-----',error);
            this.error = error ;
        }
    }

    toggleProfile(event) {
        try{
            let profileDiv = this.template.querySelector('.profile-box');
            console.log('profileDiv----',profileDiv);
            if(profileDiv.className.includes('profile-hidden')) {
                console.log('true----');
                profileDiv.classList.remove('profile-hidden');
                profileDiv.classList.add('profile-visible');
            }
            else {
                profileDiv.classList.remove('profile-visible');
                profileDiv.classList.add('profile-hidden');
            }
        }
        catch(e) {
            console.log(e);
        }
    }

    handleProfileClose() {
        setTimeout(() => {
            let profileDiv = this.template.querySelector('.profile-box');
            profileDiv.classList.remove('profile-visible');
            profileDiv.classList.add('profile-hidden');
        }, 300);
    }


    handleProfile(){
        console.log('entered handleprofile');
        this.redirectToCommunityCustomPage('my-account', {});
        console.log('exicuted');
    }

    logoutUser(){
        console.log('entered logout');
        this.logoutCommunityUser();
        console.log('Exicuted');
    }

    redirectToCart() {
        this.redirectToCommunityCustomPage('payment-cart', {});
    }

    redirectToMyApplications() {
        this.navigateToObjectListView('BusinessLicenseApplication');
    }

    redirectToMyRecords() {
        this.navigateToObjectListView('BusinessLicense');
    }

    redirectToMyCollections() {
        this.redirectToCommunityCustomPage('my-collections', {});
    }
    redirectToMyDashboard() {
        this.redirectToCommunityCustomPage('dashboard', {});
    }
    redirectToMyRegulatorycodeviolations() {
        this.navigateToObjectListView('RegulatoryCodeViolation');
    }

    redirectToHomePage() {
        this.redirectToCommunityHome();
    }
       
       
}