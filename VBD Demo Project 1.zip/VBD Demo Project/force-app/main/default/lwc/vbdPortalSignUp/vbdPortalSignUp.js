import { LightningElement, track, wire } from 'lwc';
import createUserRegistrationRecord from '@salesforce/apex/VBD_PortalSignUpCtrl.createUserRegistrationRecord';
// import {getObjectInfo} from 'lightning/uiObjectInfoApi';
// import {getPicklistValues } from "lightning/uiObjectInfoApi";
// import CONTACT_OBJECT from '@salesforce/schema/Contact';
// import GENDER_FIELD from '@salesforce/schema/Contact.Gender';
import Utility from 'c/utility';
export default class VbdPortalSignUp extends Utility {

    @track showLoader = false; 
    showSuccessMessage = false;
    showErrorMessage = false;
    @track errorMessage;
    @track confirmPassword;
    @track genderOptions = [];

    @track showStep1 = true;
    @track showStep2 = false;
    GenderOption;

    genderOptions = [{label:'Male',value:'Male'},
                        {label:'Female',value:'Female'},
                        {label:'Other',value:'Other'},
                        {label:'Unknown',value:'Unknown'}];

    // @wire(getObjectInfo, { objectApiName: CONTACT_OBJECT }) targetedPopulationsObjectInfo;
    
    // @wire(getPicklistValues, { recordTypeId: '$targetedPopulationsObjectInfo.data.defaultRecordTypeId', fieldApiName: GENDER_FIELD})
    // wiredClassOfWorkValues({ data, error }) {
    //     if (data) {
    //         this.genderOptions = data.values;
    //         console.log("##this.genderOptions--.", this.genderOptions);

    //     } else if (error) {
    //         console.log("error: ",error);
    //     }
    // }

    initData() {
        this.recordLocal = {};
        console.log("🚀 ~ this.recordLocal", this.recordLocal);
    }

    handleContinue() {
        let allValid = this.validateInputs();
        if(allValid) {
            this.showStep1 = false;
            this.showStep2 = true;
        }else{
            this.setErrorMessage('Please complete all required fields.', true);
            this.DismissErrorNotification();
        }
    }

    setErrorMessage( errorMessage, showErrorMessage) {
        this.errorMessage = errorMessage;
        this.showErrorMessage = showErrorMessage;
    }

    DismissErrorNotification(){
        setTimeout(() => {
            this.errorMessage = '';
            this.showErrorMessage = false;
        }, 3000);
    }


    fieldChanged(event){
        console.log("event.target.value---.", event.target.value);
        this.recordLocal[event.target.getAttribute('data-field')] = event.target.value;
        console.log("🚀 ~ this.recordLocal", JSON.stringify(this.recordLocal));
    }

    handleGenderOptions(event){
        console.log("event.target.value---.", event.target.value);
        this.recordLocal.Gender = event.target.value;
        console.log("🚀 ~ this.recordLocal", JSON.stringify(this.recordLocal));
    }

    signUp() {
        this.errorMessage = '';
        this.showErrorMessage = false;
        let allValid = this.validateInputs();
        //let passwordValid = this.confirmPasswordBlur();
        console.log('JSON.stringify(this.recordLocal)--->',JSON.stringify(this.recordLocal));
            if(allValid) {
            this.showLoader = true;
            console.log('record----',JSON.stringify(this.recordLocal));
            this.executeAction(createUserRegistrationRecord, { 'record': JSON.stringify(this.recordLocal), 'GenderOption' : this.recordLocal.Gender}, (response) => {
                console.log('response-----',response); 
                this.showSuccessMessage = true;
                this.showStep1 = false;
                this.showStep2 = false;
                this.showLoader = false;
                
            }, (error) => {
                console.log('e----',error);
                if(error.body.message == 'User Exists') {
                    this.errorMessage = 'User already exists with same email address';
                    this.showErrorMessage = true;
                }
                else {
                    this.errorMessage = 'User already exists with same email address';
                    this.showErrorMessage = true;
                }
                this.showLoader = false;
            }); 
        }
        else {
            this.errorMessage = 'Please complete all required fields';
            this.showErrorMessage = true;
        } 
    }
        
    phoneFieldChanged(event) {
        this.recordLocal.Phone = event.target.value;
        this.handleAccountPhoneValidation();
    }

    handleAccountPhoneValidation(){
        let allValidPhone = true;
        if(this.recordLocal.Phone != '' && this.recordLocal.Phone != undefined) {
            let phoneFieldCmp = this.template.querySelector('.phoneInput');
            let phoneRegex =  /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
            let phoneNum =  this.recordLocal.Phone;   //this.contactRec.Email;
            let phoneMatcher = phoneRegex.test(phoneNum);
            if(phoneMatcher == false ){
                allValidPhone = false;
                phoneFieldCmp.setCustomValidity('Phone Number not in proper format');
            } else {
                phoneFieldCmp.setCustomValidity('');
            }
            phoneFieldCmp.reportValidity();
        }
        return  allValidPhone;
    }

    navigateSignIn(){
        let urlString = window.location.href;
        console.log('urlString---',urlString);
        let baseURL = urlString.substring(0, urlString.indexOf('/s/'));
        console.log('baseURL---',baseURL);
        baseURL = baseURL+'/s/login';
        console.log('baseURL---',baseURL);
        window.location.href = baseURL
    }

    // handleBack(){
    // console.log('handleBack--');
    // console.log('this.showStep1--',this.showStep1);
    // this.showStep1 = true;
    // this.showStep2 = false;
    // console.log('this.showStep1--',this.showStep1);
    // }
    
}