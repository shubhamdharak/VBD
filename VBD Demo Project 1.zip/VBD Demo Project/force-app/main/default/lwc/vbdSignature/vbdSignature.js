import { LightningElement, track } from 'lwc';
import getBonusClaim from '@salesforce/apex/VBD_BonusClaimCreationCtrl.getBonusClaim';
import Utility from 'c/utility';
let isDownFlag,
    isDotFlag = false,
    prevX = 0,
    currX = 0,
    prevY = 0,
    currY = 0;

let x = "#000000"; //blue color
let y = 1.5; //weight of line width and dot.       

let canvasElement, ctx; //storing canvas context
let attachment; //holds attachment information after saving the sigture on canvas
let dataURL, convertedDataURI; //holds image data
import saveSignature from '@salesforce/apex/VBD_BonusClaimCreationCtrl.saveSignature';

export default class CapturequestedEventignature extends Utility {
    @track showCheckBox = false;
    @track showCheckBox2 = false;
    @track recordLocal = {}
    @track bounsClaimRec ={};
    @track bounsName;
    @track showLoader = false;
    @track claimId;
    initData() {
        this.claimId = this.getURLParameter('claimId');
                this.getBounsCaimRecord();
    }

    // addEvents() {
    //     canvasElement.addEventListener('mousemove', this.handleMouseMove.bind(this));
    //     canvasElement.addEventListener('mousedown', this.handleMouseDown.bind(this));
    //     canvasElement.addEventListener('mouseup', this.handleMouseUp.bind(this));
    //     canvasElement.addEventListener('mouseout', this.handleMouseOut.bind(this));

    // }

    renderedCallback() {
        try{
            console.log('in render---');
            this.template.querySelector('.path').setProgress();
        }
        catch(e) {
            console.log('e----'+JSON.stringify(e));
        }
    }

    
    async getBounsCaimRecord() {
        console.log('getBounsCaimRecord :---------1--------->' + this.claimId);

        await getBonusClaim({ recordId: this.claimId })
            .then(result => {
                console.log('result :-----> ' + result);
                this.recordLocal = result;
                this.bounsClaimRec = result;
                this.bounsName = result.Bonus_Type__r.Name;
                this.showLoader = false;
            })
            .catch(error => {
                this.error = error;
                console.log('error--createBonusCalim-->' + JSON.stringify(this.error));
            })

    }

    // handleMouseMove(event) {
    //     console.log('handleMouseMove');
    //     this.searchCoordinatesForEvent('move', event);
    // }

    // handleMouseDown(event) {
    //     console.log('handleMouseDown');
    //     this.searchCoordinatesForEvent('down', event);
    // }

    // handleMouseUp(event) {
    //     console.log('handleMouseUp');
    //     this.searchCoordinatesForEvent('up', event);
    // }

    // handleMouseOut(event) {
    //     console.log('handleMouseOut');
    //     this.searchCoordinatesForEvent('out', event);
    // }


    // handleSaveClick() {


    // }


    // handleClearClick() {
    //     ctx.clearRect(0, 0, canvasElement.width, canvasElement.height);
    // }

    // searchCoordinatesForEvent(requestedEvent, event) {
    //     //event.preventDefault();
    //     if (requestedEvent === 'down') {
    //         this.setupCoordinate(event);
    //         isDownFlag = true;
    //         isDotFlag = true;
    //         if (isDotFlag) {
    //             this.drawDot();
    //             isDotFlag = false;
    //         }
    //     }
    //     if (requestedEvent === 'up' || requestedEvent === "out") {
    //         isDownFlag = false;
    //     }
    //     if (requestedEvent === 'move') {
    //         if (isDownFlag) {
    //             this.setupCoordinate(event);
    //             this.redraw();
    //         }
    //     }
    // }

    // //This method is primary called from mouse down & move to setup cordinates.
    // setupCoordinate(eventParam) {
    //     //get size of an element and its position relative to the viewport 
    //     //using getBoundingClientRect which returns left, top, right, bottom, x, y, width, height.
    //     const clientRect = canvasElement.getBoundingClientRect();
    //     prevX = currX;
    //     prevY = currY;
    //     currX = eventParam.clientX - clientRect.left;
    //     currY = eventParam.clientY - clientRect.top;
    // }

    // //For every mouse move based on the coordinates line to redrawn
    // redraw() {
    //     ctx.beginPath();
    //     ctx.moveTo(prevX, prevY);
    //     ctx.lineTo(currX, currY);
    //     ctx.strokeStyle = x; //sets the color, gradient and pattern of stroke
    //     ctx.lineWidth = y;
    //     ctx.closePath(); //create a path from current point to starting point
    //     ctx.stroke(); //draws the path
    // }

    // //this draws the dot
    // drawDot() {
    //     ctx.beginPath();
    //     ctx.fillStyle = x; //blue color
    //     ctx.fillRect(currX, currY, y, y); //fill rectrangle with coordinates
    //     ctx.closePath();
    // }

    // renderedCallback() {
    //     if (this.showCheckBox == true) {
    //         console.log('--renderedCallback->' + this.template.querySelector('canvas'));
    //         canvasElement = this.template.querySelector('canvas');
    //         ctx = canvasElement.getContext("2d");
    //         ctx.lineCap = 'round';
    //         this.addEvents();

    //     }



    // }
    // signIt(e) {
    //     var signText = e.detail.value;
    //     this.fileName = signText;
    //     ctx.font = "30px GreatVibes-Regular";
    //     this.handleClearClick(e);
    //     ctx.fillText(signText, 30, canvasElement.height / 2);
    // }
    // handleCheckBox(event) {
    //     this.showCheckBox = event.target.checked;

    // }
    // handleCheckBox2(event) {
    //     this.showCheckBox2 = event.target.checked;
    //     console.log('showCheckBox2---1-->' + event.target.value);
    //     console.log('showCheckBox2----->' + this.showCheckBox2);
    // }

    hanblesprevious() {
        this.redirectToCommunityCustomPage('bonus-claim-service-history', { 'claimId': this.claimId });
    }
    hanbleContinue() {
        this.redirectToCommunityCustomPage('bonus-claim-preview', { 'claimId': this.claimId });
        if (this.showCheckBox == true) {
            dataURL = canvasElement.toDataURL("image/jpg");
            //convert that as base64 encoding
            convertedDataURI = dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
            console.log('convertedDataURI---->' + convertedDataURI);
            saveSignature({ signElement: convertedDataURI, recId:this.claimId  })
                .then(result => {
                    let saveSignature = result
                    // if (saveSignature == true) {
                    //     this.dispatchEvent(
                    //         new ShowToastEvent({
                    //             title: 'Success',
                    //             message: 'Signature Image saved in record',
                    //             variant: 'success',
                    //         }),
                    //     );

                    // }

                })


    }
}
}