import { LightningElement, track } from 'lwc';
import Utility from 'c/utility';
import savelater from '@salesforce/apex/VBD_ApplicantInformationCtrl.savelater';
import getbonusClaim from '@salesforce/apex/VBD_BonusClaimCreationCtrl.getBonusClaim';
export default class VbdBonusClaimServiceHistory extends Utility {
    @track claimId;
    @track showLoader;
    @track bounsClaimRec ={};
    @track bounsName;
    initData() {
        this.claimId = this.getURLParameter('claimId');
        this.getBounsClaimRecord();
    }

    async getBounsClaimRecord() {
        console.log('getBounsCaimRecord :---------1--------->' + this.claimId);

        await getbonusClaim({ recordId: this.claimId })
            .then(result => {
                console.log('result :-----> ' +JSON.stringify( result));
                this.bounsClaimRec = result;
                this.bounsName = result.Bonus_Type__r.Name;
                this.showLoader = false;
            })
            .catch(error => {
                this.error = error;
                console.log('error--createBonusCalim-->' + JSON.stringify(this.error));
            })

    }

    renderedCallback() {
        try{
            console.log('in render---');
            this.template.querySelector('.path').setProgress();
        }
        catch(e) {
            console.log('e----'+JSON.stringify(e));
        }
    }

    // hanblesprevious() {
    //     this.redirectToCommunityCustomPage('show-applicant-information', { 'claimId': this.claimId });
    // }
    hanbleContinue(){
        this.redirectToCommunityCustomPage('bonus-claim-documentation', { 'claimId': this.claimId });
    }
    hanblesprevious() {
        this.showLoader = true;
        var urlString = window.location.href;
        this.saveCurrentURL = urlString;

         savelater({ claimId:this.claimId , portalUrl: this.saveCurrentURL})
            .then(result => {
                let bonusClaimRec = result;
                this.showLoader = false;
               this.redirectToCommunityHome();
            })
            .catch(error => {
                this.showLoader = false;
                this.error = error;
                console.log('error---->' + JSON.stringify(this.error));
            })

    }

}