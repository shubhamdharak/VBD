import { LightningElement, track } from 'lwc';
import Utility from 'c/utility';
import { CloseActionScreenEvent } from 'lightning/actions';
import getCordinaters from '@salesforce/apex/VBD_AssignReviewersCtrl.getCordinaters';
import getBonusClaimRecords from '@salesforce/apex/VBD_AssignReviewersCtrl.getBonusClaimRecords';
import assignCordinator from '@salesforce/apex/VBD_AssignReviewersCtrl.assignCordinatorFromTables';
export default class VbdAssignReviewersTable extends Utility {
    @track showBcRecord = true;
    @track showCordinate = false;
    @track bonusClaimRecList = [];
    @track cordinatersList = [];
    // @track selectedCodinator = [];
    @track bcshowErrorMessage = false; 
    @track selectedRowsList = [];
    @track selectedCodinator;
    @track showLoader=  false;
    @track bonusClaimColumns = [
        { label: 'Bonus Claim Name', fieldName: 'BcRedirect', type: 'url',typeAttributes: { label: { fieldName: 'Name' }, target: '_blank' } },
        { label: 'Bonus Type', fieldName: 'BRedirect', type: 'url',typeAttributes: { label: { fieldName: 'BonusType' }, target: '_blank' } },
        { label: 'Service Member', fieldName: 'ServiceRedirect' , type: 'url',typeAttributes: { label: { fieldName: 'ServiceName' }, target: '_blank' } },
        { label: 'Submitted Date', fieldName: 'Submitted_Date__c' }
    ];
     @track columns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Email', fieldName: 'Email' }
    ];
    initData() {
        this.showLoader =true;
        this.getCoordinatersMethod();
        this.getBonusClaimRecordMethod();
    }

    handleRefresh() {
        this.showLoader =true;
        this.getCoordinatersMethod();
        this.getBonusClaimRecordMethod();
    }
    async getCoordinatersMethod() {
        console.log('Inside getCoordinatersMethod');

        await getCordinaters()
            .then(result => {
                this.cordinatersList = result;
                console.log('result--2-->' + JSON.stringify(this.cordinatersList));
            })
            .catch(error => {
                this.error = error;
                console.log('error--2-->' + JSON.stringify(this.error));
            })
    }
    async getBonusClaimRecordMethod() {
        await getBonusClaimRecords()
            .then(result => {
                this.bonusClaimRecList = result.map(value => {
                    console.log('1--->' + JSON.stringify(value));
                    return { ...value, ServiceName: value.Service_Member__r.Name, BonusType: value.Bonus_Type__r.Internal_Name__c, BcRedirect:'/' + value.Id ,BRedirect:'/' + value.Bonus_Type__c,ServiceRedirect:'/' +value.Service_Member__c }
                });
                console.log('result--1-->' + JSON.stringify(this.bonusClaimRecList));
                this.showLoader =false;

            })
            .catch(error => {
                this.error = error;
                console.log('error--1-->' + JSON.stringify(this.error));
            })
    }

    handleNext() {
        this.selectedRowsList = [];
        let selectedRecords=[];
        let a = this.template.querySelector("lightning-datatable").getSelectedRows();
       a.forEach(currentItem => {
        selectedRecords.push(currentItem.Id);
        this.selectedRowsList.push(currentItem.Id)
       });
        console.log('selectedRecords--------->'+JSON.stringify(selectedRecords));
        console.log('selectedRecords--------->'+JSON.stringify(this.selectedRowsList));
        if(selectedRecords.length == 0) {
            this.bcshowErrorMessage= true;
            setTimeout(() => {
                this.bcshowErrorMessage=false
                }, 4000);
        }else{
            this.showCordinate = true;
            this.showBcRecord = false;

        }
    }

    handleDismiss(){
        this.showCordinate = false;
        this.showBcRecord = true;
    }
    handleAssign(event){
        if(this.selectedRowsList.length > 0){
            this.showLoader =true;
            assignCordinator({ userId :this.selectedCodinator , recordIds : this.selectedRowsList })
            .then(result => {
                
                 this.getBonusClaimRecordMethod();
                this.showSuccessNotification ('Success','Coordinator is assigned successfully.');
                this.showCordinate = false;
                this.showBcRecord = true;
               

                console.log('result---->' + JSON.stringify(this.cordinatersList));
            })
            .catch(error => {
                this.error = error;
                this.showLoader =false;
                console.log('error---->' + JSON.stringify(this.error));
            })

        }else{
            this.showErrorMessage = true;
             setTimeout(() => {
                this.showErrorMessage=false
                }, 4000);
        } 
    }

       selectedRow(event ){
        this.selectedCodinator =event.detail.selectedRows[0].Id;
        console.log('ID---->' +JSON.stringify(event.detail));
        console.log('ID---1->' +JSON.stringify(event.detail.selectedRows[0].Id));
    }


}