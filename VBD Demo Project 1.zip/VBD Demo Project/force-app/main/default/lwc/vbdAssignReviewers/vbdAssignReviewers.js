import { LightningElement, track,api } from 'lwc';
import Utility from 'c/utility';
import { CloseActionScreenEvent } from 'lightning/actions';
import getCordinaters from '@salesforce/apex/VBD_AssignReviewersCtrl.getCordinaters';
import assignCordinator from '@salesforce/apex/VBD_AssignReviewersCtrl.assignCordinator';
export default class VbdAssignReviewers extends Utility {
    @track columns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Email', fieldName: 'Email' }
    ];
    @track cordinatersList=[];
    @api recordId;
    @track selectedCodinator;
    @track showErrorMessage =false;

    initData() {
        getCordinaters()
            .then(result => {
                this.cordinatersList = result;
                console.log('result---->' + JSON.stringify(this.cordinatersList));
            })
            .catch(error => {
                this.error = error;
                console.log('error---->' + JSON.stringify(this.error));
            })

    }
    selectedRow(event ){
        this.selectedCodinator =event.detail.selectedRows[0].Id;
        console.log('ID---->' +JSON.stringify(event.detail));
        console.log('ID---1->' +JSON.stringify(event.detail.selectedRows[0].Id));
    }
    handleAssign(event){
        if(this.selectedCodinator != null){

            assignCordinator({ userId :this.selectedCodinator , recordId : this.recordId })
            .then(result => {
                this.showSuccessNotification ('Success','Coordinator is assigned successfully.');
                this.dispatchEvent(new CloseActionScreenEvent());
                console.log('result---->' + JSON.stringify(this.cordinatersList));
            })
            .catch(error => {
                this.error = error;
                console.log('error---->' + JSON.stringify(this.error));
            })

        }else{
            this.showErrorMessage = true;
             setTimeout(() => {
                this.showErrorMessage=false
                }, 4000);
        }

      

    }
}