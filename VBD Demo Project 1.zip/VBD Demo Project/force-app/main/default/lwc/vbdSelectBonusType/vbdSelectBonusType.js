import { LightningElement } from 'lwc';
export default class VbdSelectBonusType extends LightningElement {

}