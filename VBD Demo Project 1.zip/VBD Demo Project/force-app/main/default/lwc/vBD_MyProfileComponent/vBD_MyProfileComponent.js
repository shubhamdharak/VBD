import { LightningElement, track, wire } from 'lwc';
import getAccountDetails from '@salesforce/apex/VBD_MyProfileController.getAccount';
import { CurrentPageReference } from 'lightning/navigation';
import updateAccount from '@salesforce/apex/VBD_MyProfileController.updateAccount';
import getNameChangesPicklistValues from '@salesforce/apex/VBD_MyProfileController.getNameChangesPicklistValues';
import getPersonGenderIdentityPicklistValues from '@salesforce/apex/VBD_MyProfileController.getPersonGenderIdentityPicklistValues';
import getPersonHowDidPicklistValues from '@salesforce/apex/VBD_MyProfileController.getPersonHowDidPicklistValues';
import getAreYouOutOfCountryPicklistValues from '@salesforce/apex/VBD_MyProfileController.getAreYouOutOfCountryPicklistValues';
 
 
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
 
export default class VBD_MyProfileComponent extends LightningElement {
    @track isSaving = false;
    @track isSave = false;
    @track save = false;
    @track account = {};
    @track error;
    @track nameChangesOptions = [];
    @track genderOptions = [];
    @track howDidOptions =[];
    @track alternateOptions = [];
    @track recordLocal = {};
    isLoader = true;
    @track contactInfoLoader = false;
    @track addressInfoLoader = false;
    @track alternateContactInfoLoader = false;
 
 @wire(CurrentPageReference)
    getPageReferenceParameters(currentPageReference) {
       if (currentPageReference) {
          //console.log(JSON.stringify(currentPageReference));
          this.getAccountDetailsFromBackend();
       }
    }
 
    getAccountDetailsFromBackend() {
        getAccountDetails({})
		.then(result => {
			this.account = { ...result }; // Ensures reactivity
            this.isLoader = false;
            this.updateRecordLocalData();
		})
		.catch(error => {
			this.error = error;
            console.log('Fetched error:', JSON.stringify(this.error));
            this.showToast('Error', 'Failed to fetch Account data', 'error');
		})
    }
    /*@wire(getAccountDetails)
    wiredAccount({ error, data }) {
        if (data) {
            this.account = { ...data }; // Ensures reactivity
            this.isLoader = false;
            this.updateRecordLocalData();
        } else if (error) {
            this.error = error;
            console.log('Fetched error:', JSON.stringify(this.error));
            this.showToast('Error', 'Failed to fetch Account data', 'error');
        }
    }*/
 
    @wire(getNameChangesPicklistValues)
    wiredPicklistValues({ error, data }) {
        if (data) {
            this.nameChangesOptions = data.map(value => ({ label: value, value: value }));
            console.log('Picklist Values:', JSON.stringify(this.nameChangesOptions));
        } else if (error) {
            console.error('Error fetching picklist values:', error);
            this.showToast('Error', 'Failed to fetch picklist values', 'error');
        }
    }

    @wire(getPersonGenderIdentityPicklistValues)
    wiredGenderPicklist({ error, data }) {
        if (data) {
            this.genderOptions = data.map(value => ({ label: value, value: value }));
            console.log('Picklist Values:', JSON.stringify(this.genderOptions));
        } else if (error) {
            console.error('Error fetching picklist values:', error);
            this.showToast('Error', 'Failed to fetch picklist values', 'error');
        }
    }
 
    @wire(getPersonHowDidPicklistValues)
    wiredHowDidPicklist({ error, data }) {
        if (data) {
            this.howDidOptions = data.map(value => ({ label: value, value: value }));
            console.log('Picklist Values:', JSON.stringify(this.howDidOptions));
        } else if (error) {
            console.error('Error fetching picklist values:', error);
            this.showToast('Error', 'Failed to fetch picklist values', 'error');
        }
    }

    @wire(getAreYouOutOfCountryPicklistValues)
    wiredAreYouPicklist({ error, data }) {
        if (data) {
            this.alternateOptions = data.map(value => ({ label: value, value: value }));
            console.log('Picklist Values:', JSON.stringify(this.alternateOptions));
        } else if (error) {
            console.error('Error fetching picklist values:', error);
            this.showToast('Error', 'Failed to fetch picklist values', 'error');
        }
    }

    handleCancle(event){
        this.updateRecordLocalData();

    }

    handleInputChange(event) {
        const field = event.target.dataset.field;
        const value = event.detail.value;
        console.log(`Field updated: ${field}, New Value: ${value}`);
 
        if (field) {
            this.account = { ...this.account, [field]: value };
            console.log('Updated account object:', JSON.stringify(this.account));
        }
        if (field === 'NameChanges' && value === 'No') {
            this.account.PreviousFirstName = '';
            this.account.PreviousMiddle = '';
            this.account.PreviousLastName = '';
        }

        if (field === 'areyou' && value === 'No') {
            this.account.ContactAlternateName = '';
            this.account.alternateContactRelationship = '';
            this.account.alternateContactEmail = '';
            this.account.alternateContactPhone = '';
            this.account.OtherPostalCode = '';
            this.account.OtherStreet = '';
            this.account.OtherCity = '';
            this.account.OtherState = '';
        }
    }
 
    handleSubmit(event) {
        this.isSaving = true;
        this.isSave = true;
        this.save = true;
         console.log('--------->'+event.target.dataset.field);
        //  if(event.target.dataset.field =='contactInfo'){
        //     this.contactInfoLoader = true;
        //  }
        //  if(event.target.dataset.field =='addressInfo'){
        //     this.addressInfoLoader = true;
        //  }
        //  if(event.target.dataset.field =='alternateContactInfo'){
        //     this.alternateContactInfoLoader = true;

        //  }
        console.log('Submitting account:', JSON.stringify(this.account));
        // let allValid = this.validateInputs();
        // if (allValid) {
                updateAccount({ accWrapper: JSON.stringify(this.account) })
                    .then(() => {
                        this.showToast('Success', 'Contact details updated successfully', 'success');
                    /*  setTimeout(() => {
                            location.reload(); // Refreshes the page
                        }, 2000); */ 

                        this.updateRecordLocalData();
                        this.contactInfoLoader = false;
                        this.addressInfoLoader = false;
                        this.alternateContactInfoLoader = false;
                
                })
                .catch(error => {
                    this.showToast('Error', 'Failed to update account', 'error');
                    console.error(error);
            })
                    .finally(() => {
                        this.isSaving = false;
                        this.isSave = false;
                        this.save = false; // Hide spinner when saving is done
                    });
        // }
    }

    handleEdit(event) {
        let dataField = event.target.dataset.field; 
        this.updateRecordLocalData();
        if(dataField == 'contactInfo') {     
            
           this.recordLocal.isContactReadOnly = false;
           this.recordLocal.disableSaveCancelContact = false;
        }

        if(dataField == 'addressInfo') {     
            this.recordLocal.isAddressReadOnly = false;
            this.recordLocal.disableSaveCancelAddress = false;
        }

        if(dataField == 'alternateContactInfo') {     
            this.recordLocal.isAlternateContactReadOnly = false;
            this.recordLocal.disableSaveCancelAlternateContact = false;
            
        }
    }

    updateRecordLocalData(){
        this.recordLocal.isContactReadOnly = true;
        this.recordLocal.isAddressReadOnly = true;
        this.recordLocal.isAlternateContactReadOnly = true;
        
        this.recordLocal.disableSaveCancelContact = true;
        this.recordLocal.disableSaveCancelAddress = true;
        this.recordLocal.disableSaveCancelAlternateContact = true;

    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
    get isNameChanged() {
        return this.account?.NameChanges === 'Yes';
    }
   
    get isAreyouChanged() {
            return this.account?.areyou === 'Yes';
    }

    get getrecordLocal() {
        return this.recordLocal;
    }

    get getLoder() {
        return this.isLoader;
    }
   get defaultCountry() {
        return this.account?.MailingCountry ? this.account.MailingCountry : 'US';
    }
}