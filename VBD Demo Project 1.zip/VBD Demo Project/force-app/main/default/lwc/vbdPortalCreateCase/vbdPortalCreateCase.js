import { LightningElement,track } from 'lwc';
import getUserContactDetails from '@salesforce/apex/VBD_PortalSignUpCtrl.getUserContactDetails';
import getBonusClaimDetail from '@salesforce/apex/VBD_PortalSignUpCtrl.getBonusClaimDetail';
import saveCase from '@salesforce/apex/VBD_PortalSignUpCtrl.saveCase';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import USER_ID from '@salesforce/user/Id';

export default class VbdPortalCreateCase extends LightningElement {
    @track isLoading = false;
    @track recordId;
    @track showBonusClaimLookUp = false;
    @track bonusClaimName;
    recordLocal = {};
    isGuestUser = false;
    correctUserId = USER_ID;
    contactDetail = {};
    @track bonusClaim;
    dateNow = new Date();


    connectedCallback() {
        this.processParametersAfterS();
        if (!USER_ID || USER_ID === '000000000000000') {
            this.isGuestUser = true;
            console.log('Guest User detected');
        } else {
            this.isGuestUser = false;
            console.log('Authenticated User detected:', USER_ID);
           this.handletogetContactDetail();
        }
        this.dateNow = new Date().toISOString().split('T')[0];
        console.log("today : "+this.dateNow );
    }

    async processParametersAfterS() {
        const parametersAfterS = this.getParametersAfterS();
        console.log('Parameters after /s/:', parametersAfterS);

        const urlParams = new URLSearchParams(window.location.search);
        const bonusClaimId = urlParams.get('claimId');
        console.log('bonusClaimId from URL:', bonusClaimId);

        const currentUrl = window.location.href;
        const isCreateCasePath = currentUrl.includes('/s/create-case'); 
        if (parametersAfterS === undefined) {
            console.log('parametersAfterS is undefined--->');
            return;
        } else if (isCreateCasePath && bonusClaimId) {
            this.recordId = bonusClaimId;
            this.recordLocal.Bonus_Claim__c = this.recordId;
            this.showBonusClaimLookUp = true;
            console.log('###this.recordId---->', this.recordId);
            this.fetchBonusClaimDetails();
        } else {
            console.log('No matching parameters found');
        }
    }

    getParametersAfterS() {
        const currentUrl = window.location.href;
        const splitUrl = currentUrl.split('/s/');
        if (splitUrl.length > 1) {
            return splitUrl[1];
        }
        return undefined; 
    }

    fetchBonusClaimDetails() {
        getBonusClaimDetail({ recordId: this.recordId })
        .then(result => {
            this.bonusClaim = result.BonusClaim;
            console.log('##this.bonusClaim:', this.bonusClaim.Name);
            this.bonusClaimName = this.bonusClaim.Name;
        })
        .catch((error) => {
            console.error('Error fetching bonusClaim:', error);
        });
    }
    handletogetContactDetail() {
    console.log('Enter into getContact method');
    getUserContactDetails({ userId: this.correctUserId })
        .then((response) => {
            console.log('Apex Response:', response);
            console.log('Apex Response Contact:', response.ContactDetails);
            this.contactDetail = response.ContactDetails;
            this.dateNow = response.date;
            console.log('this.contactDetail : ', this.contactDetail);
        })
        .catch((error) => {
            console.error('get contact Detail error: ', error);
        });
    }

    fieldChanged(event){
        console.log("event.target.value---.", event.target.value);
        this.recordLocal[event.target.getAttribute('data-field')] = event.target.value;
        this.recordLocal.Submitted_Date__c = this.dateNow;
        if(this.isGuestUser == false){
            this.recordLocal.contactId = this.contactDetail.Id;
            this.recordLocal.SSN__c = this.contactDetail.SSN__c;
            this.recordLocal.ContactEmail = this.contactDetail.Email;
        }
        console.log("🚀 ~ this.recordLocal", JSON.stringify(this.recordLocal));
    }

    handleCreateCase() {
        console.log('JSON.stringify(this.recordLocal)--->', JSON.stringify(this.recordLocal));
        this.isLoading = true;
        saveCase({ recCase: JSON.stringify(this.recordLocal),isGuest : this.isGuestUser })
             .then((response) => {
                console.log('Apex Response:', response);
                if (response.status === 'success') {
                    console.log('Response:', response);
                    setTimeout(() => {
                        this.isLoading = false; 
                        this.showToast('Success', response.message, 'success');
                                if(this.isGuestUser == false){
                                    window.location.href = '/vbc/s/';
                                }else{
                                window.location.href = '/vbc/s/login';
                                }
                        }, 1000);
                                
                            } else {
                                setTimeout(() => {
                                // Show error toast
                                this.isLoading = false; 
                                console.log ('Error :', response.message, 'error');
                                this.showToast('Error', response.message, 'error');
                            }, 1000);
                            }
            })
            .catch((error) => {
                        console.error('Error creating case: ', error);
                        this.showToast('Error', 'An unknown error occurred. Please try again later.', 'error');
                    });
    }

    // Helper method to display toast messages
    showToast(title, message, variant) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        });
        this.dispatchEvent(event);
    }
}