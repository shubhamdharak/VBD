import { LightningElement } from 'lwc';
import LoginImage from '@salesforce/resourceUrl/LoginImage';
import loginWithPassword from '@salesforce/apex/LPI_Portal_LoginCtrl.loginWithPassword';
import verifyUserExist from '@salesforce/apex/LPI_Portal_LoginCtrl.verifyUserExist';
import sendLoginOtp from '@salesforce/apex/LPI_Portal_LoginCtrl.sendLoginOtp';
import verifyUserCode from '@salesforce/apex/LPI_Portal_LoginCtrl.verifyUserCode';
import { NavigationMixin } from 'lightning/navigation';
export default class LpiPortal_Login extends NavigationMixin(LightningElement) {

    error;
    code;
    identifier;
    userId;
    emailAddress;
    password;
    startUrl;
    errorMessage;
    notificationMessage;
    showVerificationScreen = false;  
    showPasswordScreen = false;
    showEmailOTPScreen = false;
    showNotificationMessage = false;
    showSuccessMessage = false;
    showErrorMessage = false;
    showLoader = false;

    loginLogo = LoginImage;

    /********************************************************************************************
    * Method Name  : handleFirstPageNext
    * Description  : on first page verify user exist/present on database or not
    * Author       : 
    * Created On   : 11-08-2023
    * Modification : 13-09-2023
    ************************************************************************************************/
    async handleFirstPageNext() {
        this.errorMessage = '';
        this.showErrorMessage = false;
        if (!this.Email__c) {
            
            this.setErrorMessage('Please enter an email address.', true);
            this.DismissErrorNotification();
            return;
        }
        console.log('#email address---->',this.Email__c);
        try{
            const result = await verifyUserExist({ 'emailAddress': this.Email__c });
            if(result == true){
                console.log('user is present');
                this.showVerificationScreen = true;
                this.showEmailOTPScreen = false;
                this.showPasswordScreen = true;
            }
            else{
                console.log('user is NOT present');
                this.setErrorMessage('This account cannot be found. Please use a different account or sign up for a new account.', true);
                this.DismissErrorNotification();
            }
        }
        catch(error) {
			console.log('error-----',error);
            this.setErrorMessage('An error occurred while checking the email address.', true);
            this.DismissErrorNotification();
        }
    }

    /********************************************************************************************
    * Method Name  : handleLoginwithPasswords
    * Description  : login with password functionality
    * Author       : 
    * Created On   : 11-08-2023
    * Modification : 13-09-2023
    ************************************************************************************************/
    async handleLoginwithPasswords(){
        try {
            if(!this.isInputValid()){ 
                this.errorMessage = '';
                this.showErrorMessage = false;
                return;
            }
            const result = await loginWithPassword({ 'username' : this.Email__c, 'password': this.password, 'startUrl': this.startUrl });
            console.log('startUrl---->',this.startUrl);
            if(result['success']){
                console.log('success');
                window.location.href = result['url'];
            }else{
                this.showSuccessMessage = true;
                this.showLoader = false;
            }
        }catch(err) {
            console.error(JSON.stringify(err));
            this.setErrorMessage('Your login attempt has failed. Make sure the username and password are correct.', true);
            this.DismissErrorNotification();
        }
    }

   /********************************************************************************************
    * Method Name  : handleSendOtp
    * Description  : send OTP on registered email address
    * Author       : 
    * Created On   : 11-08-2023
    * Modification : 13-09-2023
    ************************************************************************************************/ 
    async handleSendOtp() {
        try{
            this.notificationMessage = '';
            this.showNotificationMessage = false;
            //console.log('emailAddress---->',this.Email__c);
            const response = await sendLoginOtp({'email':this.Email__c});
            //console.log('response----',response);
            let responseMap = JSON.parse(response.selfRegistrationString);      //got String from apex side
            //console.log('#responseMap----',responseMap);
            this.identifier = responseMap.identifier;
            this.userId = response.userId;
            this.setNotificationMessage('OTP send on your register email address',true);
            this.DismissOtpNotification();
            this.OtpExipredMessage();
        }
        catch(error) {
            console.log('error----',error);
        }
    }

    /********************************************************************************************
    * Method Name  : handleVerifyUserCode
    * Description  : verify code is valid or not
    * Author       : 
    * Created On   : 11-08-2023
    * Modification : 13-09-2023
    ************************************************************************************************/
    async handleVerifyUserCode() {          
        this.errorMessage = '';
        this.showErrorMessage = false;

        if (!this.Verification_Code__c) {
            this.errorMessage = 'Please enter the OTP';
            this.showErrorMessage = true;
            this.DismissErrorNotification();
            return;
        }

        //console.log('#this.identifier-----',this.identifier); 
        //console.log('#this.code-----',this.code); 
        //console.log('#this.userId-----',this.userId); 
        try{
            const response = await verifyUserCode({ 'identifier': this.identifier, 'code': this.code, 'userId': this.userId});
            console.log('response-----',response);
            console.log('response.redirect----->',response.redirect);
            window.location.href = response.redirect;
        }
        catch(error) {
            if(error.body.message.includes('Invalid verification code')){
                this.setErrorMessage('Incorrect OTP. Please try again.', true);
                this.DismissErrorNotification();
            }else if(error.body.message.includes('Login expired')){
                this.setErrorMessage('Your OTP has been expired. Please try again by clicking resend OTP', true);
                this.DismissErrorNotification();
            }else if(error.body.message.includes("We can't log in the user")){
                this.setErrorMessage('To many attempty, Please try in sometime', true);
                this.DismissErrorNotification();
            }
        }
    }

    /********************************************************************************************
    * Method Name  : handleNavigateLoginPassword
    * Description  : Navigate to login with password screen
    * Author       : 
    * Created On   : 11-08-2023
    * Modification : 13-09-2023
    ************************************************************************************************/
    
    handleNavigateLoginPassword(){
        this.showErrorMessage = false;
        this.Verification_Code__c = undefined;
        this.showEmailOTPScreen = false;
        this.showPasswordScreen = true;
        this.showVerificationScreen = true;
    }

    /********************************************************************************************
    * Method Name  : handleNavigateToEmailOTP
    * Description  : Navigate to email otp screen
    * Author       : 
    * Created On   : 11-08-2023
    * Modification : 13-09-2023
    ************************************************************************************************/
    handleNavigateToEmailOTP() {
        this.showErrorMessage = false;
        this.showEmailOTPScreen = true;
        this.showPasswordScreen = false;
        this.showVerificationScreen = true;
        this.handleSendOtp();
    }

    /********************************************************************************************
    * Method Name  : handleResendVerificationCode
    * Description  : resend verification code
    * Author       : 
    * Created On   : 11-08-2023
    * Modification : 13-09-2023
    ************************************************************************************************/
    handleResendVerificationCode(){
        this.handleSendOtp();
    }

    /********************************************************************************************
    * Method Name  : handleChangeButton
    * Description  : method used for change buttton
    * Author       : 
    * Created On   : 11-08-2023
    * Modification : 13-09-2023
    ************************************************************************************************/
    handleChangeButton(){
        this.Verification_Code__c = undefined;
        this.Email__c = undefined;
        this.showErrorMessage = false;
        this.showVerificationScreen = false;
    }

   /********************************************************************************************
    * Method Name  : handleFieldBlur
    * Description  : After Username blur handle field values
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/ 
    handleFieldBlur(event){
        const fieldName = event.target.name;
        if(fieldName == 'username' && event.target.value){
            this.username = event.target.value.trim();
        }
        else if(fieldName == 'password' && event.target.value){
            this.password = event.target.value.trim();
        }
        else if(fieldName == 'Verification Code' && event.target.value){
            this.Verification_Code__c = event.target.value.trim();
        }
    }

    /********************************************************************************************
    * Method Name  : handleFieldChange
    * Description  : this function is used to set username and password 
    * Author       : 
    * Created On   :
    * Modification Log: 
    ************************************************************************************************/ 
    handleFieldChange(event){
        const fieldName = event.target.name;
        if(fieldName == 'username'){
            this.username = event.target.value;
        }else if(fieldName == 'password'){
            this.password = event.target.value;
        }else if(fieldName == 'Verification Code'){
            this.code = event.target.value;
        }
        let dataField = event.target.dataset.field;
        console.log('#dataField----->',dataField);
        if(dataField =='Email__c'){
            this.Email__c = event.target.value;
        }
    }
    
    /********************************************************************************************
    * Method Name  : handleNavigateSignUp
    * Description  : this function is used to navigate to signUp page.
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/ 
    handleNavigateSignUp(){
        this.redirectToCommunityPage('Register',{});
    }
    
     /********************************************************************************************
    * Method Name  : handleNavigateToForgotPassword
    * Description  : this function is used to navigate to signUp page.
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/
    handleNavigateToForgotPassword(){
        this.redirectToCommunityPage('Forgot_Password',{});
    }

    /********************************************************************************************
    * Method Name  : handleNavigateToForgotPassword
    * Description  : this function is used to navigate to signUp page.
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/

    handleNavigateToCaseCreation(){
        window.location.href = '/vbc/s/create-case';
    }

    /********************************************************************************************
    * Method Name  : redirectToCommunityPage
    * Description  : this function is used for navigation
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/
    redirectToCommunityPage = (namedPage, stateJSON) => {
        console.log("page name : " + namedPage);
        console.log("stateJSON : " + stateJSON);      

        if (stateJSON == undefined) {
            stateJSON = {};
        }

        // Prepare the new pagereferance
        let pageReference = {};
        pageReference.type = 'comm__namedPage';
        pageReference.attributes = {'name': namedPage};  // Please note that name should be page API name ending with __c
        pageReference.state = stateJSON;
        // Navigate to the new pagereferance
        this[NavigationMixin.Navigate](
            pageReference,
            false
        );
    }

    redirectToCommunityCustomPage = (namedPage, stateJSON) => {

        console.log("inside nav" + namedPage);
        console.log("stateJSON" + stateJSON);
        //https://developer.salesforce.com/docs/component-library/documentation/en/lwc/lwc.reference_page_reference_type
        if (stateJSON == undefined) {
            stateJSON = {};
        }
        console.log("inside nav2 " + namedPage);
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: namedPage,
            },
            state: stateJSON
        });
    }


    /********************************************************************************************
    * Method Name  : DismissOtpNotification
    * Description  : notification message disappear after 3 sec
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/
    DismissOtpNotification(){
        setTimeout(() => {
            this.notificationMessage = '';
            this.showNotificationMessage = false;
        }, 3000);
    }

    /********************************************************************************************
    * Method Name  : DismissErrorNotification
    * Description  : Error message disappear after 3 sec
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/
    DismissErrorNotification(){
        setTimeout(() => {
            this.errorMessage = '';
            this.showErrorMessage = false;
        }, 3000);
    }

    /********************************************************************************************
    * Method Name  : isInputValid
    * Description  : validate Input
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/
    isInputValid() {
        let isValid = true;
        let inputFields = this.template.querySelectorAll('.validate');
        inputFields.forEach(inputField => {
            if(!inputField.checkValidity()) {
                inputField.reportValidity();
                isValid = false;
            }
        });
        return isValid;
    }

    /********************************************************************************************
    * Method Name  : setErrorMessage
    * Description  : error function
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/
    setErrorMessage( errorMessage, showErrorMessage) {
        this.errorMessage = errorMessage;
        this.showErrorMessage = showErrorMessage;
    }

    /********************************************************************************************
    * Method Name  : setNotificationMessage
    * Description  : Notification function
    * Author       : 
    * Created On   :05-05-2023
    * Modification Log: 
    ************************************************************************************************/
    setNotificationMessage( notificationMessage, showNotificationMessage) {
        this.notificationMessage = notificationMessage;
        this.showNotificationMessage = showNotificationMessage;
    }
}