declare module "@salesforce/resourceUrl/LoginImage" {
    var LoginImage: string;
    export default LoginImage;
}