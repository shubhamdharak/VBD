declare module "@salesforce/apex/VBD_PortalSignatureCtrl.saveSignature" {
  export default function saveSignature(param: {ContentVersionData: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_PortalSignatureCtrl.currentUserSignature" {
  export default function currentUserSignature(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_PortalSignatureCtrl.updateFileTypeToSign" {
  export default function updateFileTypeToSign(param: {contentVersionId: any, contentDocId: any}): Promise<any>;
}
