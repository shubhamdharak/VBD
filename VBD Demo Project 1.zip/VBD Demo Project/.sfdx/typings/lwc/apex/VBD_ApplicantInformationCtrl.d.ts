declare module "@salesforce/apex/VBD_ApplicantInformationCtrl.getApplicantInforamtion" {
  export default function getApplicantInforamtion(param: {userId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_ApplicantInformationCtrl.createContact" {
  export default function createContact(param: {alternateConatct: any, alternateContact: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_ApplicantInformationCtrl.getAlternateConatct" {
  export default function getAlternateConatct(param: {userId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_ApplicantInformationCtrl.savelater" {
  export default function savelater(param: {claimId: any, portalUrl: any}): Promise<any>;
}
