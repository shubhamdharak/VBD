declare module "@salesforce/apex/VBD_GeneralSearchCtrl.searchGenericRecords" {
  export default function searchGenericRecords(param: {searchTerm: any}): Promise<any>;
}
