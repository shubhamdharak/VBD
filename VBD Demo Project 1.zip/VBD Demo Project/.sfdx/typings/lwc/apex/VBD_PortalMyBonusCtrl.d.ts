declare module "@salesforce/apex/VBD_PortalMyBonusCtrl.getBLADetails" {
  export default function getBLADetails(param: {userId: any}): Promise<any>;
}
