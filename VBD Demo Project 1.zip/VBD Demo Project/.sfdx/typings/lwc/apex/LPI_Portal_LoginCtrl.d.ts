declare module "@salesforce/apex/LPI_Portal_LoginCtrl.loginWithPassword" {
  export default function loginWithPassword(param: {username: any, password: any, startUrl: any}): Promise<any>;
}
declare module "@salesforce/apex/LPI_Portal_LoginCtrl.verifyUserExist" {
  export default function verifyUserExist(param: {emailAddress: any}): Promise<any>;
}
declare module "@salesforce/apex/LPI_Portal_LoginCtrl.sendLoginOtp" {
  export default function sendLoginOtp(param: {email: any}): Promise<any>;
}
declare module "@salesforce/apex/LPI_Portal_LoginCtrl.verifyUserCode" {
  export default function verifyUserCode(param: {identifier: any, code: any, userId: any, startUrl: any}): Promise<any>;
}
