declare module "@salesforce/apex/VBD_BonusClaimCreationCtrl.createBonusCalim" {
  export default function createBonusCalim(param: {bounsClaimRec: any, userId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_BonusClaimCreationCtrl.getContact" {
  export default function getContact(param: {userID: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_BonusClaimCreationCtrl.createBonusCalimSaveLater" {
  export default function createBonusCalimSaveLater(param: {bounsClaimRec: any, portalUrl: any, userId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_BonusClaimCreationCtrl.getBonusClaim" {
  export default function getBonusClaim(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_BonusClaimCreationCtrl.saveSignature" {
  export default function saveSignature(param: {signElement: any, recId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_BonusClaimCreationCtrl.getSignature" {
  export default function getSignature(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_BonusClaimCreationCtrl.createBc" {
  export default function createBc(param: {bonusType: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_BonusClaimCreationCtrl.finalBcSave" {
  export default function finalBcSave(param: {bcRecordId: any}): Promise<any>;
}
