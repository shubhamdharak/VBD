declare module "@salesforce/apex/VBD_DocumentUploadeCtrl.checkIfPortalUser" {
  export default function checkIfPortalUser(): Promise<any>;
}
declare module "@salesforce/apex/VBD_DocumentUploadeCtrl.getDocumentType" {
  export default function getDocumentType(): Promise<any>;
}
declare module "@salesforce/apex/VBD_DocumentUploadeCtrl.documentUploads" {
  export default function documentUploads(param: {fileIds: any, documentTypeId: any, claimId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_DocumentUploadeCtrl.getBonusClaimDetail" {
  export default function getBonusClaimDetail(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_DocumentUploadeCtrl.cloneDocumentFromProfile" {
  export default function cloneDocumentFromProfile(param: {documentId: any, ContentDocumentIds: any, claimId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_DocumentUploadeCtrl.deleteDocument" {
  export default function deleteDocument(param: {documentId: any}): Promise<any>;
}
