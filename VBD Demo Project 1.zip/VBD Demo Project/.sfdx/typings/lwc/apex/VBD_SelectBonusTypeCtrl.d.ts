declare module "@salesforce/apex/VBD_SelectBonusTypeCtrl.getBonusTypes" {
  export default function getBonusTypes(): Promise<any>;
}
