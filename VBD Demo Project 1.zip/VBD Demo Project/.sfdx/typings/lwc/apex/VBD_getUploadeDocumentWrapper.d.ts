declare module "@salesforce/apex/VBD_getUploadeDocumentWrapper.fetchDocuments" {
  export default function fetchDocuments(param: {recordId: any}): Promise<any>;
}
