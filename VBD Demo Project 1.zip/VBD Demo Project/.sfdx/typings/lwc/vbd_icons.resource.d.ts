declare module "@salesforce/resourceUrl/vbd_icons" {
    var vbd_icons: string;
    export default vbd_icons;
}