declare module "@salesforce/resourceUrl/VBD_portalHeaderlogo" {
    var VBD_portalHeaderlogo: string;
    export default VBD_portalHeaderlogo;
}