declare module "@salesforce/apex/VBD_PortalSignUpCtrl.createUserRegistrationRecord" {
  export default function createUserRegistrationRecord(param: {record: any, GenderOption: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_PortalSignUpCtrl.createCaseCreationRecord" {
  export default function createCaseCreationRecord(param: {record: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_PortalSignUpCtrl.getUserContactDetails" {
  export default function getUserContactDetails(param: {userId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_PortalSignUpCtrl.getBonusClaimDetail" {
  export default function getBonusClaimDetail(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_PortalSignUpCtrl.saveCase" {
  export default function saveCase(param: {recCase: any, isGuest: any}): Promise<any>;
}
