declare module "@salesforce/apex/OrderGridController.getOrderProducts" {
  export default function getOrderProducts(param: {communityId: any, effectiveAccountId: any, productIdTest: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderGridController.getCartSummary" {
  export default function getCartSummary(param: {webstoreId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderGridController.addToCart" {
  export default function addToCart(param: {productsJSON: any, communityId: any, effectiveAccountId: any}): Promise<any>;
}
