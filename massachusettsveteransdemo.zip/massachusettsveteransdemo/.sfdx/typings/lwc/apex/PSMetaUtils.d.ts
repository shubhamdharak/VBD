declare module "@salesforce/apex/PSMetaUtils.getMetaFieldDesc2" {
  export default function getMetaFieldDesc2(param: {objtype: any, filterFields: any}): Promise<any>;
}
declare module "@salesforce/apex/PSMetaUtils.getMetaFieldDesc3" {
  export default function getMetaFieldDesc3(param: {objtype: any, filterFields: any}): Promise<any>;
}
declare module "@salesforce/apex/PSMetaUtils.getMetaFieldDesc" {
  export default function getMetaFieldDesc(param: {objtype: any, filterFields: any}): Promise<any>;
}
declare module "@salesforce/apex/PSMetaUtils.getSingleFieldDesc" {
  export default function getSingleFieldDesc(param: {objtype: any, fld: any}): Promise<any>;
}
