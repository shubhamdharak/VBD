declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.getAddressInfo" {
  export default function getAddressInfo(param: {effectiveAccountId: any, isShipping: any, isBilling: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.fetchInitValues" {
  export default function fetchInitValues(param: {communityId: any, effectiveAccountId: any, cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.resolveCommunityIdToWebstoreId" {
  export default function resolveCommunityIdToWebstoreId(param: {communityId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.getCartSummary" {
  export default function getCartSummary(param: {effectiveAccountId: any, webstoreId: any, activeOrCartId: any, recalculateTax: any, useDefaultRate: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.fetchDeliveryMethods" {
  export default function fetchDeliveryMethods(param: {cartId: any, cartCurrency: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.setCartItemDeliveryGroup" {
  export default function setCartItemDeliveryGroup(param: {cartDeliveryGroupMethodId: any, deliveryMethodId: any, cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.setCartDeliveryGroupShipToAddress" {
  export default function setCartDeliveryGroupShipToAddress(param: {contactPointAddress: any, cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.setCartDeliveryGroupShipToAddressManual" {
  export default function setCartDeliveryGroupShipToAddressManual(param: {companyName: any, streetAddress1: any, city: any, stateProvince: any, postalCode: any, country: any, cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.fetchDefaultDeliveryMethod" {
  export default function fetchDefaultDeliveryMethod(param: {cartId: any, cartCurrency: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_SPC_ComponentController.fetchCartDeliveryGroupAddress" {
  export default function fetchCartDeliveryGroupAddress(param: {cartId: any}): Promise<any>;
}
