declare module "@salesforce/apex/SDO_B2BCommerce_FeaturedProducts.getUserAccountID" {
  export default function getUserAccountID(): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_FeaturedProducts.getProductsByFieldValue" {
  export default function getProductsByFieldValue(param: {webstoreId: any, effectiveAccountId: any, fieldApiName: any, fieldValue: any, compareType: any, includePrices: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_FeaturedProducts.getProductsBySku" {
  export default function getProductsBySku(param: {webstoreId: any, effectiveAccountId: any, skuList: any, includePrices: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_FeaturedProducts.getProductsByCategoryId" {
  export default function getProductsByCategoryId(param: {webstoreId: any, effectiveAccountId: any, categoryId: any, includePrices: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_FeaturedProducts.fetchInitValues" {
  export default function fetchInitValues(param: {communityId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_FeaturedProducts.resolveCommunityIdToWebstoreId" {
  export default function resolveCommunityIdToWebstoreId(param: {communityId: any}): Promise<any>;
}
