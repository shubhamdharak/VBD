declare module "@salesforce/apex/DBM25Controller.getDefaultReportFolderName" {
  export default function getDefaultReportFolderName(): Promise<any>;
}
declare module "@salesforce/apex/DBM25Controller.getPackageNamespace" {
  export default function getPackageNamespace(): Promise<any>;
}
declare module "@salesforce/apex/DBM25Controller.getPicklistValues" {
  export default function getPicklistValues(param: {objectName: any, fieldName: any}): Promise<any>;
}
declare module "@salesforce/apex/DBM25Controller.getReportFolders" {
  export default function getReportFolders(): Promise<any>;
}
declare module "@salesforce/apex/DBM25Controller.getReportDetailRecords" {
  export default function getReportDetailRecords(): Promise<any>;
}
declare module "@salesforce/apex/DBM25Controller.deleteReports" {
  export default function deleteReports(param: {reportDetailRecordIds: any, reportIds: any}): Promise<any>;
}
declare module "@salesforce/apex/DBM25Controller.saveReportDetails" {
  export default function saveReportDetails(param: {reportDetailsString: any}): Promise<any>;
}
declare module "@salesforce/apex/DBM25Controller.createReport" {
  export default function createReport(param: {reportDetailsRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/DBM25Controller.sendFeedback" {
  export default function sendFeedback(param: {subject: any, body: any}): Promise<any>;
}
