declare module "@salesforce/apex/AutoCompleteController.getRecords" {
  export default function getRecords(param: {searchString: any, objectApiName: any, valueFieldApiName: any, extendedWhereClause: any, maxRecords: any, extraObjects: any, SearchScope: any, QueryType: any, Bypasssharing: any}): Promise<any>;
}
declare module "@salesforce/apex/AutoCompleteController.saveResult" {
  export default function saveResult(param: {recordId: any, fieldAPiName: any, value: any}): Promise<any>;
}
