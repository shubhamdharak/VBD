declare module "@salesforce/apex/SDO_Service_Customer360_MultipleObjects.getContact" {
  export default function getContact(param: {recid: any}): Promise<any>;
}
