declare module "@salesforce/apex/Sdo_Scom_Auction_Service.getAuctionBids" {
  export default function getAuctionBids(param: {auction: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_Scom_Auction_Service.getProductAuctionDetails" {
  export default function getProductAuctionDetails(param: {request: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_Scom_Auction_Service.addAuctionBid" {
  export default function addAuctionBid(param: {request: any}): Promise<any>;
}
