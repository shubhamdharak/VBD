declare module "@salesforce/apex/Sdo_scom_product_reviews.getCustomObjects" {
  export default function getCustomObjects(): Promise<any>;
}
