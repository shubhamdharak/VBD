declare module "@salesforce/apex/SDO_Einstein_Discovery_OpptyCT.getEDInfo" {
  export default function getEDInfo(param: {opptyId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Einstein_Discovery_OpptyCT.checkExecMeeting" {
  export default function checkExecMeeting(param: {opptyId: any}): Promise<any>;
}
