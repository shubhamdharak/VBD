declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.getRecordData" {
  export default function getRecordData(param: {recordId: any, sobjectType: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.getLeadFields" {
  export default function getLeadFields(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.getLeadIQConfiguration" {
  export default function getLeadIQConfiguration(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.getModelFactor" {
  export default function getModelFactor(param: {version: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.getLeadInsights" {
  export default function getLeadInsights(param: {leadId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.getEngagementScore" {
  export default function getEngagementScore(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.deleteModelFactors" {
  export default function deleteModelFactors(param: {modelFactors: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.deleteLeadInsights" {
  export default function deleteLeadInsights(param: {leadInsights: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.saveOpportunityScore" {
  export default function saveOpportunityScore(param: {scoreData: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.upsertScoreIntelligence" {
  export default function upsertScoreIntelligence(param: {scoreIntelligence: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.upsertModelFactors" {
  export default function upsertModelFactors(param: {modelFactors: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.upsertLeadInsight" {
  export default function upsertLeadInsight(param: {leadInsights: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.upsertData" {
  export default function upsertData(param: {sObjectType: any, objectData: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.handleSaveRecords" {
  export default function handleSaveRecords(param: {endpoint: any, method: any, data: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.restInsertRequest" {
  export default function restInsertRequest(param: {singleRecord: any, objectName: any, data: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.restUpdateRequest" {
  export default function restUpdateRequest(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_EMC_BehaviorScoringController.httpRequest" {
  export default function httpRequest(param: {auth: any, endpoint: any, method: any, data: any}): Promise<any>;
}
