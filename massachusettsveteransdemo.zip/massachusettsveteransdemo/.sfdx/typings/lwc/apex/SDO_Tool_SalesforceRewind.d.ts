declare module "@salesforce/apex/SDO_Tool_SalesforceRewind.getSessionId" {
  export default function getSessionId(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_SalesforceRewind.getOrgType" {
  export default function getOrgType(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_SalesforceRewind.getRecording" {
  export default function getRecording(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_SalesforceRewind.setRecording" {
  export default function setRecording(param: {value: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_SalesforceRewind.getRewindRecords" {
  export default function getRewindRecords(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_SalesforceRewind.deleteAllRecords" {
  export default function deleteAllRecords(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_SalesforceRewind.deleteARecord" {
  export default function deleteARecord(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_SalesforceRewind.rewindARecord" {
  export default function rewindARecord(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_SalesforceRewind.trackMixpanel" {
  export default function trackMixpanel(param: {body: any}): Promise<any>;
}
