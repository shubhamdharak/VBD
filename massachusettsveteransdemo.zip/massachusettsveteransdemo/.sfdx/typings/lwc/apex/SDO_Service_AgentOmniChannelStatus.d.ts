declare module "@salesforce/apex/SDO_Service_AgentOmniChannelStatus.getUserStatus" {
  export default function getUserStatus(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_AgentOmniChannelStatus.getUser" {
  export default function getUser(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_AgentOmniChannelStatus.getCases" {
  export default function getCases(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_AgentOmniChannelStatus.getOnlinePresenceStatus" {
  export default function getOnlinePresenceStatus(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_AgentOmniChannelStatus.getBusyPresenceStatus" {
  export default function getBusyPresenceStatus(): Promise<any>;
}
