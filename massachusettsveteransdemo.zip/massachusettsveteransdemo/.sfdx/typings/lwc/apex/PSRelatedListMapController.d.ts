declare module "@salesforce/apex/PSRelatedListMapController.getRelatedRecords" {
  export default function getRelatedRecords(param: {params: any}): Promise<any>;
}
