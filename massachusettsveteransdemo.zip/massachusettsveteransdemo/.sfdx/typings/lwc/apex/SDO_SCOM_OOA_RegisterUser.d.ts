declare module "@salesforce/apex/SDO_SCOM_OOA_RegisterUser.getDomains" {
  export default function getDomains(): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_OOA_RegisterUser.createRequest" {
  export default function createRequest(param: {accId: any, rFname: any, rLname: any, rEmail: any, rPhone: any, rRole: any}): Promise<any>;
}
