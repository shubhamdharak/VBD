declare module "@salesforce/apex/gps_UpdateContractControllerOnChild.getUpdatedRecord" {
  export default function getUpdatedRecord(param: {sourceRecordId: any, autoDocgen: any}): Promise<any>;
}
