declare module "@salesforce/apex/Sdo_Scom_CheckoutCreditLimitService.getAvailableCreditLimit" {
  export default function getAvailableCreditLimit(param: {effectiveAccountId: any}): Promise<any>;
}
