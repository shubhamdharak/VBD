declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_GetInfo.getProduct" {
  export default function getProduct(param: {communityId: any, productId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_GetInfo.checkProductIsInStock" {
  export default function checkProductIsInStock(param: {productId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_GetInfo.getCartSummary" {
  export default function getCartSummary(param: {communityId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_GetInfo.addToCart" {
  export default function addToCart(param: {communityId: any, productId: any, quantity: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_GetInfo.createAndAddToList" {
  export default function createAndAddToList(param: {communityId: any, productId: any, wishlistName: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_GetInfo.getProductPrice" {
  export default function getProductPrice(param: {communityId: any, productId: any, effectiveAccountId: any}): Promise<any>;
}
