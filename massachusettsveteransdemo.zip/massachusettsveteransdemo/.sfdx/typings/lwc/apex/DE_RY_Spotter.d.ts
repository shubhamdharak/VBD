declare module "@salesforce/apex/DE_RY_Spotter.getUserAccountID" {
  export default function getUserAccountID(): Promise<any>;
}
declare module "@salesforce/apex/DE_RY_Spotter.getAllConfigurations" {
  export default function getAllConfigurations(): Promise<any>;
}
declare module "@salesforce/apex/DE_RY_Spotter.createConfigRecord" {
  export default function createConfigRecord(param: {name: any, documentId: any}): Promise<any>;
}
declare module "@salesforce/apex/DE_RY_Spotter.changeImage" {
  export default function changeImage(param: {configId: any, documentId: any}): Promise<any>;
}
declare module "@salesforce/apex/DE_RY_Spotter.getPublicDistURL" {
  export default function getPublicDistURL(param: {documentId: any}): Promise<any>;
}
declare module "@salesforce/apex/DE_RY_Spotter.getConfig" {
  export default function getConfig(param: {configId: any}): Promise<any>;
}
declare module "@salesforce/apex/DE_RY_Spotter.saveHotspots" {
  export default function saveHotspots(param: {configRec: any, hotspots: any, hotspotsToDelete: any}): Promise<any>;
}
declare module "@salesforce/apex/DE_RY_Spotter.deleteRecord" {
  export default function deleteRecord(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/DE_RY_Spotter.getEmbedInfo" {
  export default function getEmbedInfo(param: {spotterMode: any, configId: any, communityId: any, effectiveAccountId: any, productRecordId: any}): Promise<any>;
}
