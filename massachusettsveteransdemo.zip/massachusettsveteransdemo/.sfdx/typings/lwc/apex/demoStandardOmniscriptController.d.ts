declare module "@salesforce/apex/demoStandardOmniscriptController.demoOmniscript" {
  export default function demoOmniscript(param: {OSType: any}): Promise<any>;
}
