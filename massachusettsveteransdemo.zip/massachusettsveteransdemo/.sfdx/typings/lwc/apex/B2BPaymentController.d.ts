declare module "@salesforce/apex/B2BPaymentController.getPaymentInfo" {
  export default function getPaymentInfo(param: {cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2BPaymentController.setPayment" {
  export default function setPayment(param: {paymentType: any, cartId: any, billingAddress: any, paymentInfo: any}): Promise<any>;
}
