declare module "@salesforce/apex/PSObjectSearchController.query" {
  export default function query(param: {queryStr: any}): Promise<any>;
}
declare module "@salesforce/apex/PSObjectSearchController.prepFilterFields" {
  export default function prepFilterFields(param: {objtype: any, filterFields: any}): Promise<any>;
}
declare module "@salesforce/apex/PSObjectSearchController.prepTableFields" {
  export default function prepTableFields(param: {objtype: any, tableFields: any}): Promise<any>;
}
declare module "@salesforce/apex/PSObjectSearchController.getRuntimeContext" {
  export default function getRuntimeContext(): Promise<any>;
}
