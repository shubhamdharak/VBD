declare module "@salesforce/apex/B2B_FeaturedProducts_Controller.getProductsByFieldValue" {
  export default function getProductsByFieldValue(param: {webstoreId: any, effectiveAccountId: any, fieldApiName: any, fieldValue: any, compareType: any, includePrices: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_FeaturedProducts_Controller.getProductsBySku" {
  export default function getProductsBySku(param: {webstoreId: any, effectiveAccountId: any, skuList: any, includePrices: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_FeaturedProducts_Controller.getProductsByCategoryId" {
  export default function getProductsByCategoryId(param: {webstoreId: any, effectiveAccountId: any, categoryId: any, includePrices: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_FeaturedProducts_Controller.fetchInitValues" {
  export default function fetchInitValues(param: {communityId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_FeaturedProducts_Controller.resolveCommunityIdToWebstoreId" {
  export default function resolveCommunityIdToWebstoreId(param: {communityId: any}): Promise<any>;
}
