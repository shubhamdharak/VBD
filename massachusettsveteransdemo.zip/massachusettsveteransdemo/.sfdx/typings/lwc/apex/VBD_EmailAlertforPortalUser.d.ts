declare module "@salesforce/apex/VBD_EmailAlertforPortalUser.sendingEmail" {
  export default function sendingEmail(param: {recordid: any}): Promise<any>;
}
