declare module "@salesforce/apex/SDO_CMS_RetrieveSingleArticle.getContentArticle" {
  export default function getContentArticle(param: {externalId: any, sfRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_CMS_RetrieveSingleArticle.getArticlesFromCollection" {
  export default function getArticlesFromCollection(param: {externalId: any}): Promise<any>;
}
