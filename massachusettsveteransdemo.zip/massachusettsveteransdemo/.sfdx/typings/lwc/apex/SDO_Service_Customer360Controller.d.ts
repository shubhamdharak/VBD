declare module "@salesforce/apex/SDO_Service_Customer360Controller.getRecordDetails" {
  export default function getRecordDetails(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_Customer360Controller.getAccountAddresses" {
  export default function getAccountAddresses(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_Customer360Controller.getOrders" {
  export default function getOrders(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_Customer360Controller.getOrderDetails" {
  export default function getOrderDetails(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_Customer360Controller.getOrderLineItems" {
  export default function getOrderLineItems(param: {recordId: any}): Promise<any>;
}
