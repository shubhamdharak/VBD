declare module "@salesforce/apex/SDO_B2B_Cart_CustomValidation.fetchInitValues" {
  export default function fetchInitValues(param: {communityId: any, effectiveAccountId: any, cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2B_Cart_CustomValidation.resolveCommunityIdToWebstoreId" {
  export default function resolveCommunityIdToWebstoreId(param: {communityId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2B_Cart_CustomValidation.fetchCustomCartValidation" {
  export default function fetchCustomCartValidation(param: {cartId: any}): Promise<any>;
}
