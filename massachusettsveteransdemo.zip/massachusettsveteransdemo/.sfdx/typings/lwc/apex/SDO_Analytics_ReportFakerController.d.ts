declare module "@salesforce/apex/SDO_Analytics_ReportFakerController.saveFakeData" {
  export default function saveFakeData(param: {fakeDataString: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Analytics_ReportFakerController.getExistingFakeData" {
  export default function getExistingFakeData(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Analytics_ReportFakerController.getExistingGroupMembers" {
  export default function getExistingGroupMembers(param: {reportName: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Analytics_ReportFakerController.getBaseReportId" {
  export default function getBaseReportId(): Promise<any>;
}
