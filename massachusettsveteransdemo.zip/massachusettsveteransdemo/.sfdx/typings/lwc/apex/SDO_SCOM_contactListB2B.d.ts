declare module "@salesforce/apex/SDO_SCOM_contactListB2B.getContactList" {
  export default function getContactList(): Promise<any>;
}
