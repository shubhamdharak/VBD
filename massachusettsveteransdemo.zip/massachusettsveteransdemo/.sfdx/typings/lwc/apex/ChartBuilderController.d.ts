declare module "@salesforce/apex/ChartBuilderController.getChartData" {
  export default function getChartData(param: {chartDataProviderType: any, ctx: any}): Promise<any>;
}
