declare module "@salesforce/apex/SDO_Einstein_HomeInsightHelper.getRecordId" {
  export default function getRecordId(param: {recordName: any, objectType: any}): Promise<any>;
}
