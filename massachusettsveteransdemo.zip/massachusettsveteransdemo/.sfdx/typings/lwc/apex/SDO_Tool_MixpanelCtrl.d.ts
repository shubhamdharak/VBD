declare module "@salesforce/apex/SDO_Tool_MixpanelCtrl.getToken" {
  export default function getToken(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_MixpanelCtrl.sendSimpleMixpanelEvent" {
  export default function sendSimpleMixpanelEvent(param: {action: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_MixpanelCtrl.getOrgData" {
  export default function getOrgData(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_MixpanelCtrl.createEvent" {
  export default function createEvent(param: {data: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Tool_MixpanelCtrl.updateProfile" {
  export default function updateProfile(param: {data: any}): Promise<any>;
}
