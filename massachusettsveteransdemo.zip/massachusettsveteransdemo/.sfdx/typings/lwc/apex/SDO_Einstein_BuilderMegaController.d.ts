declare module "@salesforce/apex/SDO_Einstein_BuilderMegaController.getObjectData" {
  export default function getObjectData(param: {objid: any, objName: any, predictionField: any, factorFields: any, factorFieldsField: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Einstein_BuilderMegaController.getFieldLabels" {
  export default function getFieldLabels(param: {objName: any}): Promise<any>;
}
