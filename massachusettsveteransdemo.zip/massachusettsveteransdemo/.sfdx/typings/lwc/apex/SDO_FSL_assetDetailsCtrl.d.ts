declare module "@salesforce/apex/SDO_FSL_assetDetailsCtrl.getAsset" {
  export default function getAsset(param: {recordId: any, objectType: any}): Promise<any>;
}
