declare module "@salesforce/apex/PcProductComparisonDataServices.getFieldSetInformation" {
  export default function getFieldSetInformation(param: {objectAPIName: any, fieldsetListStr: any, comparingFieldInfo: any}): Promise<any>;
}
declare module "@salesforce/apex/PcProductComparisonDataServices.getAllObjectData" {
  export default function getAllObjectData(param: {objectAPIName: any, queryFields: any, orderByField: any, searchTerm: any, comparingField: any}): Promise<any>;
}
declare module "@salesforce/apex/PcProductComparisonDataServices.getPreSelectedObjectData" {
  export default function getPreSelectedObjectData(param: {objectAPIName: any, queryFields: any, orderByField: any, recordId: any, comparingField: any}): Promise<any>;
}
declare module "@salesforce/apex/PcProductComparisonDataServices.getProductPrice" {
  export default function getProductPrice(param: {communityId: any, accountId: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/PcProductComparisonDataServices.getUserAccountID" {
  export default function getUserAccountID(): Promise<any>;
}
declare module "@salesforce/apex/PcProductComparisonDataServices.addProductToCart" {
  export default function addProductToCart(param: {communityId: any, accountId: any, recordId: any, quantity: any}): Promise<any>;
}
declare module "@salesforce/apex/PcProductComparisonDataServices.resolveCommunityIdToWebstoreId" {
  export default function resolveCommunityIdToWebstoreId(param: {communityId: any}): Promise<any>;
}
