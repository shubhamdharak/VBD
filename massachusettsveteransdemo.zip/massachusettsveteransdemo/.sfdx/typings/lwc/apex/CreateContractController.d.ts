declare module "@salesforce/apex/CreateContractController.getCreatedRecord" {
  export default function getCreatedRecord(param: {sourceRecordId: any, autoDocgen: any}): Promise<any>;
}
