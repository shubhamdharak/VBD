declare module "@salesforce/apex/SDO_B2BCommerce_CrossSell.getCrossSellProducts" {
  export default function getCrossSellProducts(param: {communityId: any, productID: any, effectiveAccountID: any, productType: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_CrossSell.getProduct" {
  export default function getProduct(param: {webstoreId: any, productId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_CrossSell.getProductPrice" {
  export default function getProductPrice(param: {communityId: any, productId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_CrossSell.addToCart" {
  export default function addToCart(param: {communityId: any, productId: any, quantity: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_B2BCommerce_CrossSell.getUserAccountID" {
  export default function getUserAccountID(): Promise<any>;
}
