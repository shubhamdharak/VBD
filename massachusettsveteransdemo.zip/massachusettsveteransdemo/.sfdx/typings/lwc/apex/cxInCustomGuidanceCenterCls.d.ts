declare module "@salesforce/apex/cxInCustomGuidanceCenterCls.getActiveProgram" {
  export default function getActiveProgram(): Promise<any>;
}
declare module "@salesforce/apex/cxInCustomGuidanceCenterCls.getSections" {
  export default function getSections(param: {progId: any}): Promise<any>;
}
declare module "@salesforce/apex/cxInCustomGuidanceCenterCls.getAllPrograms" {
  export default function getAllPrograms(): Promise<any>;
}
declare module "@salesforce/apex/cxInCustomGuidanceCenterCls.activateProgram" {
  export default function activateProgram(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/cxInCustomGuidanceCenterCls.setExerciseAsComplete" {
  export default function setExerciseAsComplete(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/cxInCustomGuidanceCenterCls.resetProgress" {
  export default function resetProgress(param: {programId: any}): Promise<any>;
}
