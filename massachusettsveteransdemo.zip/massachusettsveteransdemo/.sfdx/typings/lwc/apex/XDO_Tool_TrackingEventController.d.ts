declare module "@salesforce/apex/XDO_Tool_TrackingEventController.getSiteId" {
  export default function getSiteId(): Promise<any>;
}
declare module "@salesforce/apex/XDO_Tool_TrackingEventController.publishTrackingEvent" {
  export default function publishTrackingEvent(param: {serializedEvent: any}): Promise<any>;
}
