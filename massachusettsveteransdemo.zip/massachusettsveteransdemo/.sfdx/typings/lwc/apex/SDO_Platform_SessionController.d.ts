declare module "@salesforce/apex/SDO_Platform_SessionController.getSessionId" {
  export default function getSessionId(): Promise<any>;
}
