declare module "@salesforce/apex/permissionSetAssignmentCopy.assignPermissionSets" {
  export default function assignPermissionSets(param: {assignFromUserIds: any, assignToUserIds: any}): Promise<any>;
}
declare module "@salesforce/apex/permissionSetAssignmentCopy.search" {
  export default function search(param: {searchTerm: any, selectedIds: any}): Promise<any>;
}
