declare module "@salesforce/apex/B2BBundle.getBundleProducts" {
  export default function getBundleProducts(param: {communityId: any, productID: any, effectiveAccountID: any}): Promise<any>;
}
declare module "@salesforce/apex/B2BBundle.getProduct" {
  export default function getProduct(param: {webstoreId: any, productId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2BBundle.searchCurrentProductPageURL" {
  export default function searchCurrentProductPageURL(): Promise<any>;
}
declare module "@salesforce/apex/B2BBundle.getProductPrice" {
  export default function getProductPrice(param: {communityId: any, productId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2BBundle.addToCart" {
  export default function addToCart(param: {communityId: any, productId: any, quantity: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2BBundle.getItemQuantity" {
  export default function getItemQuantity(param: {currentProductId: any, myBundleItem: any}): Promise<any>;
}
