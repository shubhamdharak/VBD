declare module "@salesforce/apex/SDO_SCOM_B2B_FillTheTruckService.getFilledCapacity" {
  export default function getFilledCapacity(param: {webstoreId: any, effectiveAccountId: any}): Promise<any>;
}
