declare module "@salesforce/apex/SDO_Service_ChangeTabLabelController.getNewLabel" {
  export default function getNewLabel(param: {recordId: any}): Promise<any>;
}
