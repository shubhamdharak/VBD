declare module "@salesforce/apex/SDO_SCOM_OOA_CustomCheckoutController.getCurrentUserDetails" {
  export default function getCurrentUserDetails(param: {userId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_OOA_CustomCheckoutController.getCartApprovalStatus" {
  export default function getCartApprovalStatus(param: {cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_OOA_CustomCheckoutController.requestOverride" {
  export default function requestOverride(param: {cartId: any, approverId: any, accountName: any, cartValue: any, isBudgetExceded: any, hasProductExceptions: any, productExceptions: any, orgAdminApproverId: any}): Promise<any>;
}
