declare module "@salesforce/apex/PSAccessTrackerController.createAccessRecord" {
  export default function createAccessRecord(param: {params: any}): Promise<any>;
}
declare module "@salesforce/apex/PSAccessTrackerController.reverseGeocodeEsri" {
  export default function reverseGeocodeEsri(param: {lat: any, lng: any}): Promise<any>;
}
