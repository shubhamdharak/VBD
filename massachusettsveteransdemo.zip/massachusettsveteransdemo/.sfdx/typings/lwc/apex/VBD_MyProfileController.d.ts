declare module "@salesforce/apex/VBD_MyProfileController.getAccount" {
  export default function getAccount(): Promise<any>;
}
declare module "@salesforce/apex/VBD_MyProfileController.getNameChangesPicklistValues" {
  export default function getNameChangesPicklistValues(): Promise<any>;
}
declare module "@salesforce/apex/VBD_MyProfileController.getPersonGenderIdentityPicklistValues" {
  export default function getPersonGenderIdentityPicklistValues(): Promise<any>;
}
declare module "@salesforce/apex/VBD_MyProfileController.getPersonHowDidPicklistValues" {
  export default function getPersonHowDidPicklistValues(): Promise<any>;
}
declare module "@salesforce/apex/VBD_MyProfileController.getAreYouOutOfCountryPicklistValues" {
  export default function getAreYouOutOfCountryPicklistValues(): Promise<any>;
}
declare module "@salesforce/apex/VBD_MyProfileController.updateAccount" {
  export default function updateAccount(param: {accWrapper: any}): Promise<any>;
}
