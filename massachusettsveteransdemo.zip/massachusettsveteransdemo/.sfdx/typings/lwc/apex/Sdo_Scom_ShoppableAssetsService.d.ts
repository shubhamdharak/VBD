declare module "@salesforce/apex/Sdo_Scom_ShoppableAssetsService.getShoppableAssets" {
  export default function getShoppableAssets(param: {assetId: any, webstoreId: any, effectiveAccountId: any}): Promise<any>;
}
