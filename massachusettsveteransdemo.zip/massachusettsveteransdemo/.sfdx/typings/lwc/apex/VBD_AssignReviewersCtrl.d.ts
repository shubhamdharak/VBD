declare module "@salesforce/apex/VBD_AssignReviewersCtrl.getCordinaters" {
  export default function getCordinaters(): Promise<any>;
}
declare module "@salesforce/apex/VBD_AssignReviewersCtrl.assignCordinator" {
  export default function assignCordinator(param: {userId: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/VBD_AssignReviewersCtrl.getBonusClaimRecords" {
  export default function getBonusClaimRecords(): Promise<any>;
}
declare module "@salesforce/apex/VBD_AssignReviewersCtrl.assignCordinatorFromTables" {
  export default function assignCordinatorFromTables(param: {userId: any, recordIds: any}): Promise<any>;
}
