declare module "@salesforce/apex/SDO_Service_Discovery_CaseCT.getEDInfo" {
  export default function getEDInfo(param: {caseId: any}): Promise<any>;
}
