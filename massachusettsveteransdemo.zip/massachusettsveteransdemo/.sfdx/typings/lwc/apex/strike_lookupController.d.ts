declare module "@salesforce/apex/strike_lookupController.getRecentRecords" {
  export default function getRecentRecords(param: {jsonString: any}): Promise<any>;
}
declare module "@salesforce/apex/strike_lookupController.getRecordLabel" {
  export default function getRecordLabel(param: {jsonString: any}): Promise<any>;
}
declare module "@salesforce/apex/strike_lookupController.getRecords" {
  export default function getRecords(param: {jsonString: any}): Promise<any>;
}
