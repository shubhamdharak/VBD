declare module "@salesforce/apex/SDO_SCOM_CSVCartUploadService.addToCart" {
  export default function addToCart(param: {webstoreId: any, effectiveAccountId: any, products: any}): Promise<any>;
}
