declare module "@salesforce/apex/SDO_Service_CaseSentimentCtrl.getCaseAnalysis" {
  export default function getCaseAnalysis(param: {caseId: any}): Promise<any>;
}
