declare module "@salesforce/apex/ImageCaptureController.getContentDocumentId" {
  export default function getContentDocumentId(param: {contentVersionId: any}): Promise<any>;
}
declare module "@salesforce/apex/ImageCaptureController.getContentVersionId" {
  export default function getContentVersionId(param: {uniqueCvId: any}): Promise<any>;
}
declare module "@salesforce/apex/ImageCaptureController.createContentDocumentLink" {
  export default function createContentDocumentLink(param: {contentDocumentId: any, recordId: any}): Promise<any>;
}
