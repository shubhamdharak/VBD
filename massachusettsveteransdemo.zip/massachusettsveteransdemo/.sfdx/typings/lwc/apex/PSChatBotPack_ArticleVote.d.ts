declare module "@salesforce/apex/PSChatBotPack_ArticleVote.voteArticle" {
  export default function voteArticle(param: {articleNum: any, voteUpDown: any}): Promise<any>;
}
