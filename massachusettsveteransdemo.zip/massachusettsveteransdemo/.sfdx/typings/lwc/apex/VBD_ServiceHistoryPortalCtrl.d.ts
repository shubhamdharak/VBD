declare module "@salesforce/apex/VBD_ServiceHistoryPortalCtrl.getserviceHistoryDetails" {
  export default function getserviceHistoryDetails(): Promise<any>;
}
declare module "@salesforce/apex/VBD_ServiceHistoryPortalCtrl.createServiceHistory" {
  export default function createServiceHistory(param: {contactId: any, record: any}): Promise<any>;
}
