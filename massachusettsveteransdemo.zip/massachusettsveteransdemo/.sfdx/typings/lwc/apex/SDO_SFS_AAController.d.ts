declare module "@salesforce/apex/SDO_SFS_AAController.getAssetId" {
  export default function getAssetId(param: {workOrderId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SFS_AAController.getAssetAttributes" {
  export default function getAssetAttributes(param: {assetId: any, workOrderId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SFS_AAController.getAttributePickList" {
  export default function getAttributePickList(param: {attributeId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SFS_AAController.saveAttribute" {
  export default function saveAttribute(param: {attributeId: any, attributeValue: any}): Promise<any>;
}
