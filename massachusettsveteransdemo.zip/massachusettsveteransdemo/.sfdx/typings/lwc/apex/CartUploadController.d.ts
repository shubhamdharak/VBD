declare module "@salesforce/apex/CartUploadController.getInfo" {
  export default function getInfo(param: {userId: any, effectiveAccountId: any, communityId: any, webstoreId: any}): Promise<any>;
}
declare module "@salesforce/apex/CartUploadController.processData" {
  export default function processData(param: {userId: any, rows: any, webstoreId: any, effectiveAccountId: any, cartId: any, hasHeaderRow: any, ignoreInvalidSkus: any, emailResults: any}): Promise<any>;
}
