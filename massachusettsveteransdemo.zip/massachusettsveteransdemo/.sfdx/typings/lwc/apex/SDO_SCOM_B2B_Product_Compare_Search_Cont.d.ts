declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_Search_Cont.productSearch" {
  export default function productSearch(param: {communityId: any, searchQuery: any, effectiveAccountId: any}): Promise<any>;
}
