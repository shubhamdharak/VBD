declare module "@salesforce/apex/KeyMetricsController.getMetadataValues" {
  export default function getMetadataValues(param: {customMetadataLabel: any}): Promise<any>;
}
