declare module "@salesforce/apex/UpdateContractController.getUpdatedRecord" {
  export default function getUpdatedRecord(param: {sourceRecordId: any, autoDocgen: any}): Promise<any>;
}
