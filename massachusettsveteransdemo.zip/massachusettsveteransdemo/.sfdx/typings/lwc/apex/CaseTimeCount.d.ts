declare module "@salesforce/apex/CaseTimeCount.checkAccess" {
  export default function checkAccess(): Promise<any>;
}
declare module "@salesforce/apex/CaseTimeCount.newSession" {
  export default function newSession(param: {caseId: any, timeVal: any, status: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseTimeCount.newSessionManual" {
  export default function newSessionManual(param: {caseId: any, timeVal: any, theDate: any, comments: any, status: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseTimeCount.grabSessions" {
  export default function grabSessions(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseTimeCount.totalTime" {
  export default function totalTime(param: {recordId: any}): Promise<any>;
}
