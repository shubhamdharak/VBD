declare module "@salesforce/apex/emailSettingsController.getCurrectUser" {
  export default function getCurrectUser(): Promise<any>;
}
declare module "@salesforce/apex/emailSettingsController.saveEmailPreference" {
  export default function saveEmailPreference(param: {preferences: any}): Promise<any>;
}
