declare module "@salesforce/apex/B2BCartUploadHelp.getContent" {
  export default function getContent(param: {communityId: any, contentId: any, locale: any, contentType: any}): Promise<any>;
}
