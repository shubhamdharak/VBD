declare module "@salesforce/apex/SDO_Tool_qinsight_controller.getEmail" {
  export default function getEmail(): Promise<any>;
}
