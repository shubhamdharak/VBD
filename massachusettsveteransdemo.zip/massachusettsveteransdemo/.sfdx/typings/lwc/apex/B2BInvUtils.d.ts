declare module "@salesforce/apex/B2BInvUtils.resolveCommunityIdToWebstoreId" {
  export default function resolveCommunityIdToWebstoreId(param: {communityId: any}): Promise<any>;
}
