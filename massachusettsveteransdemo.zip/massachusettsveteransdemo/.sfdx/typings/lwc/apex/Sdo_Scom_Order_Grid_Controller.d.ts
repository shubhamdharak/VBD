declare module "@salesforce/apex/Sdo_Scom_Order_Grid_Controller.getOrderProducts" {
  export default function getOrderProducts(param: {communityId: any, effectiveAccountId: any, productIdTest: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_Scom_Order_Grid_Controller.getCartSummary" {
  export default function getCartSummary(param: {webstoreId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_Scom_Order_Grid_Controller.addToCart" {
  export default function addToCart(param: {productsJSON: any, communityId: any, effectiveAccountId: any}): Promise<any>;
}
