declare module "@salesforce/apex/PSChatBotPack_SetFileApex.setFileApex" {
  export default function setFileApex(param: {recordId: any, fileId: any, fileName: any, bField: any, commAccess: any}): Promise<any>;
}
