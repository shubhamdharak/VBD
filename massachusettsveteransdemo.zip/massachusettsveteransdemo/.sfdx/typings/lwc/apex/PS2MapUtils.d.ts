declare module "@salesforce/apex/PS2MapUtils.reverseGeocode" {
  export default function reverseGeocode(param: {lat: any, lng: any}): Promise<any>;
}
