declare module "@salesforce/apex/B2B_Moodboard_Controller.getMoodBoardNames" {
  export default function getMoodBoardNames(param: {userId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_Moodboard_Controller.getMoodBoardData" {
  export default function getMoodBoardData(param: {userId: any, moodBoardId: any, communityId: any, webstoreId: any, effectiveAccountId: any, includePrices: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_Moodboard_Controller.saveMoodBoard" {
  export default function saveMoodBoard(param: {userId: any, moodBoardId: any, moodBoardName: any, effectiveAccountId: any, data: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_Moodboard_Controller.deleteMoodBoard" {
  export default function deleteMoodBoard(param: {moodBoardId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_Moodboard_Controller.getProducts" {
  export default function getProducts(param: {searchTerm: any, communityId: any, webstoreId: any, effectiveAccountId: any, includePrices: any, pageSize: any, categoryId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_Moodboard_Controller.addMoodBoardProductsToTheCart" {
  export default function addMoodBoardProductsToTheCart(param: {userId: any, communityId: any, webstoreId: any, moodBoardName: any, effectiveAccountId: any, activeCartOrId: any, data: any}): Promise<any>;
}
declare module "@salesforce/apex/B2B_Moodboard_Controller.resolveCommunityIdToWebstoreId" {
  export default function resolveCommunityIdToWebstoreId(param: {communityId: any}): Promise<any>;
}
