declare module "@salesforce/apex/sdo_scom_boost_and_bury_controller.getRule" {
  export default function getRule(param: {webStoreId: any}): Promise<any>;
}
declare module "@salesforce/apex/sdo_scom_boost_and_bury_controller.createRule" {
  export default function createRule(param: {webStoreId: any, input: any}): Promise<any>;
}
declare module "@salesforce/apex/sdo_scom_boost_and_bury_controller.deleteRule" {
  export default function deleteRule(param: {webStoreId: any, ruleId: any}): Promise<any>;
}
declare module "@salesforce/apex/sdo_scom_boost_and_bury_controller.getProducts" {
  export default function getProducts(): Promise<any>;
}
declare module "@salesforce/apex/sdo_scom_boost_and_bury_controller.getProductsById" {
  export default function getProductsById(param: {productIds: any}): Promise<any>;
}
