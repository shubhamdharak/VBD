declare module "@salesforce/apex/SDO_Service_scrubDemo_IAVisController.getIAs" {
  export default function getIAs(param: {caseID: any}): Promise<any>;
}
