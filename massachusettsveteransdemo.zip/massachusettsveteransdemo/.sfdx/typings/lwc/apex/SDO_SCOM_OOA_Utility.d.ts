declare module "@salesforce/apex/SDO_SCOM_OOA_Utility.getCurrentUserApprovals" {
  export default function getCurrentUserApprovals(): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_OOA_Utility.getCurrentCommunityUsersInfoForCompany" {
  export default function getCurrentCommunityUsersInfoForCompany(): Promise<any>;
}
