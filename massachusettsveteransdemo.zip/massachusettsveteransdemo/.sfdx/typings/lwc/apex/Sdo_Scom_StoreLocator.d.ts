declare module "@salesforce/apex/Sdo_Scom_StoreLocator.fetchLocations" {
  export default function fetchLocations(param: {distance: any, unit: any, userLatitude: any, userLongitude: any, serviceClassName: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_Scom_StoreLocator.fetchPreferredStore" {
  export default function fetchPreferredStore(param: {distance: any, unit: any, userLatitude: any, userLongitude: any, serviceClassName: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_Scom_StoreLocator.updateDefaultStore" {
  export default function updateDefaultStore(param: {storeId: any, serviceClassName: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_Scom_StoreLocator.updateLocations" {
  export default function updateLocations(param: {serviceClassName: any}): Promise<any>;
}
