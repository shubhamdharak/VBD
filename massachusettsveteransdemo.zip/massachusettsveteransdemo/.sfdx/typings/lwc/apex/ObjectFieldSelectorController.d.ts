declare module "@salesforce/apex/ObjectFieldSelectorController.getObjects" {
  export default function getObjects(param: {selectionType: any, availableObjects: any}): Promise<any>;
}
declare module "@salesforce/apex/ObjectFieldSelectorController.getObjectFields" {
  export default function getObjectFields(param: {objectName: any}): Promise<any>;
}
