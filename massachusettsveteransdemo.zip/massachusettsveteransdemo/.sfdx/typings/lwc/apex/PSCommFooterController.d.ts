declare module "@salesforce/apex/PSCommFooterController.getConfig" {
  export default function getConfig(param: {configName: any}): Promise<any>;
}
