declare module "@salesforce/apex/SDO_Platform_EventsChartController.getSessionId" {
  export default function getSessionId(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Platform_EventsChartController.getEventNames" {
  export default function getEventNames(): Promise<any>;
}
declare module "@salesforce/apex/SDO_Platform_EventsChartController.getFields" {
  export default function getFields(param: {eventName: any}): Promise<any>;
}
