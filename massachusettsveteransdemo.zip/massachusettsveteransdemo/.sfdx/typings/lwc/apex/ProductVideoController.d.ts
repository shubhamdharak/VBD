declare module "@salesforce/apex/ProductVideoController.getVideos" {
  export default function getVideos(param: {recordId: any, maxNumVideos: any, locale: any}): Promise<any>;
}
