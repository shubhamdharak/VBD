declare module "@salesforce/apex/VBD_BonusTypeSelectionCtrl.getBonusTypes" {
  export default function getBonusTypes(): Promise<any>;
}
