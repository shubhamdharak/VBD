declare module "@salesforce/apex/SDO_Service_ContactHighlight_CT.getContact" {
  export default function getContact(param: {recId: any}): Promise<any>;
}
