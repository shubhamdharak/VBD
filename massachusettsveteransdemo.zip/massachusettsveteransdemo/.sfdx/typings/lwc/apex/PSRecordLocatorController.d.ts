declare module "@salesforce/apex/PSRecordLocatorController.reverseGeocodeEsri" {
  export default function reverseGeocodeEsri(param: {lat: any, lng: any}): Promise<any>;
}
declare module "@salesforce/apex/PSRecordLocatorController.saveRecordLocation" {
  export default function saveRecordLocation(param: {params: any}): Promise<any>;
}
declare module "@salesforce/apex/PSRecordLocatorController.getCurrLocation" {
  export default function getCurrLocation(param: {params: any}): Promise<any>;
}
