declare module "@salesforce/apex/gps_CreateContractControllerOnChild.getCreatedRecord" {
  export default function getCreatedRecord(param: {sourceRecordId: any, autoDocgen: any}): Promise<any>;
}
