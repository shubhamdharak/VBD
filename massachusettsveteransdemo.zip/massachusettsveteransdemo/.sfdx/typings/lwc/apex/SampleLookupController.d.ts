declare module "@salesforce/apex/SampleLookupController.search" {
  export default function search(param: {searchTerm: any, selectedIds: any}): Promise<any>;
}
declare module "@salesforce/apex/SampleLookupController.getRecentlyViewed" {
  export default function getRecentlyViewed(): Promise<any>;
}
