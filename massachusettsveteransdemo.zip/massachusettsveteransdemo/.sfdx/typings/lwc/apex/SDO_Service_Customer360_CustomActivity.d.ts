declare module "@salesforce/apex/SDO_Service_Customer360_CustomActivity.getActivitiesForContact" {
  export default function getActivitiesForContact(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_Customer360_CustomActivity.getActivitiesForAccount" {
  export default function getActivitiesForAccount(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_Customer360_CustomActivity.getContactForAccount" {
  export default function getContactForAccount(param: {recordId: any}): Promise<any>;
}
