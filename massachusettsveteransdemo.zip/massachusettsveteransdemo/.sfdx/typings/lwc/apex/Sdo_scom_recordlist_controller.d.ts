declare module "@salesforce/apex/Sdo_scom_recordlist_controller.getApiNameOfChild" {
  export default function getApiNameOfChild(param: {recordId: any, objectName: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_scom_recordlist_controller.getFieldDetails" {
  export default function getFieldDetails(param: {objectName: any, queryType: any, fieldsToQuery: any, filters: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_scom_recordlist_controller.retrieveIconForObject" {
  export default function retrieveIconForObject(param: {objectname: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_scom_recordlist_controller.getTotalRecords" {
  export default function getTotalRecords(param: {objectName: any, filters: any, recordId: any, queryType: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_scom_recordlist_controller.getRecords" {
  export default function getRecords(param: {objectName: any, queryType: any, listViewName: any, fieldsToQuery: any, filters: any, sortField: any, sortDirect: any, recordId: any, offset: any, limitrec: any}): Promise<any>;
}
declare module "@salesforce/apex/Sdo_scom_recordlist_controller.searchrecords" {
  export default function searchrecords(param: {objectName: any, queryType: any, fieldsToQuery: any, filters: any, sortField: any, sortDirect: any, recordId: any, offset: any, limitrec: any, searchSTring: any}): Promise<any>;
}
