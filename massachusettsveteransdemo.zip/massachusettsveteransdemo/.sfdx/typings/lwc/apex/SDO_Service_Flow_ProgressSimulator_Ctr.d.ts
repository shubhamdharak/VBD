declare module "@salesforce/apex/SDO_Service_Flow_ProgressSimulator_Ctr.updateProgress" {
  export default function updateProgress(param: {currentProgress: any, speed: any}): Promise<any>;
}
