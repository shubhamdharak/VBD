declare module "@salesforce/apex/SDO_Service_MilestoneController.getCurrentMilestones" {
  export default function getCurrentMilestones(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_Service_MilestoneController.getAllMilestones" {
  export default function getAllMilestones(param: {caseId: any}): Promise<any>;
}
