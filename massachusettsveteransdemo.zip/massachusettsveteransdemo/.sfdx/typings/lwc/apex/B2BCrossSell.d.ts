declare module "@salesforce/apex/B2BCrossSell.getCrossSellProducts" {
  export default function getCrossSellProducts(param: {communityId: any, productID: any, effectiveAccountID: any, productType: any}): Promise<any>;
}
declare module "@salesforce/apex/B2BCrossSell.getProduct" {
  export default function getProduct(param: {webstoreId: any, productId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2BCrossSell.searchCurrentProductPageURL" {
  export default function searchCurrentProductPageURL(): Promise<any>;
}
declare module "@salesforce/apex/B2BCrossSell.getProductPrice" {
  export default function getProductPrice(param: {communityId: any, productId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/B2BCrossSell.addToCart" {
  export default function addToCart(param: {communityId: any, productId: any, quantity: any, effectiveAccountId: any}): Promise<any>;
}
