declare module "@salesforce/apex/PSFlowMapController.reverseGeocodeEsri" {
  export default function reverseGeocodeEsri(param: {lat: any, lng: any}): Promise<any>;
}
declare module "@salesforce/apex/PSFlowMapController.saveRecordLocation" {
  export default function saveRecordLocation(param: {params: any}): Promise<any>;
}
declare module "@salesforce/apex/PSFlowMapController.getCurrLocation" {
  export default function getCurrLocation(param: {params: any}): Promise<any>;
}
