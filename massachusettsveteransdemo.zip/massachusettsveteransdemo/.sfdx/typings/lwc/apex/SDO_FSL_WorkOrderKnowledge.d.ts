declare module "@salesforce/apex/SDO_FSL_WorkOrderKnowledge.searchAllArticles" {
  export default function searchAllArticles(param: {searchText: any, language: any, nbResult: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_FSL_WorkOrderKnowledge.searchknowledgeArticles" {
  export default function searchknowledgeArticles(param: {searchInput: any, nbResult: any, recordId: any, language: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_FSL_WorkOrderKnowledge.getNonAttachedArticles" {
  export default function getNonAttachedArticles(param: {nbResult: any, attachedListIds: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_FSL_WorkOrderKnowledge.getArticles" {
  export default function getArticles(param: {nbResult: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_FSL_WorkOrderKnowledge.getAllArticles" {
  export default function getAllArticles(param: {nbResult: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_FSL_WorkOrderKnowledge.getSuggestedArticles" {
  export default function getSuggestedArticles(param: {nbResult: any, recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_FSL_WorkOrderKnowledge.attachArticleToObject" {
  export default function attachArticleToObject(param: {recordId: any, KnowledgeArticleVersionId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_FSL_WorkOrderKnowledge.detachArticleToObject" {
  export default function detachArticleToObject(param: {recordId: any, KnowledgeArticleVersionId: any}): Promise<any>;
}
