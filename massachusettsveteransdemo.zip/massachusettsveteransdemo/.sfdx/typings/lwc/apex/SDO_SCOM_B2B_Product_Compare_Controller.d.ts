declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_Controller.fetchInitValues" {
  export default function fetchInitValues(param: {communityId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_Controller.resolveCommunityIdToWebstoreId" {
  export default function resolveCommunityIdToWebstoreId(param: {communityId: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_Controller.getProducts" {
  export default function getProducts(param: {productIdList: any, displayPrices: any, webstoreId: any, effectiveAccountId: any, facetFields: any}): Promise<any>;
}
declare module "@salesforce/apex/SDO_SCOM_B2B_Product_Compare_Controller.addToCart" {
  export default function addToCart(param: {webstoreId: any, productId: any, quantity: any, effectiveAccountId: any}): Promise<any>;
}
