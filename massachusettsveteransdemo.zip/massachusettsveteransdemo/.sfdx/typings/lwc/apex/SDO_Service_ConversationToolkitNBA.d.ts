declare module "@salesforce/apex/SDO_Service_ConversationToolkitNBA.getConversationHelperList" {
  export default function getConversationHelperList(): Promise<any>;
}
