declare module "@salesforce/apex/SDO_Tool_Utility_LookupCtrl.getLookup" {
  export default function getLookup(param: {lookupObject: any, lookupField: any, searchTerm: any, filters: any}): Promise<any>;
}
