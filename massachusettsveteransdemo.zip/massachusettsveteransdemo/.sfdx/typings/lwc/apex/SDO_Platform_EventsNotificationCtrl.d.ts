declare module "@salesforce/apex/SDO_Platform_EventsNotificationCtrl.getSessionId" {
  export default function getSessionId(): Promise<any>;
}
