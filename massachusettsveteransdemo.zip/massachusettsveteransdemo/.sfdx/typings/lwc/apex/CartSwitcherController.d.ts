declare module "@salesforce/apex/CartSwitcherController.getCarts" {
  export default function getCarts(param: {communityId: any, effectiveAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/CartSwitcherController.createCart" {
  export default function createCart(param: {communityId: any, effectiveAccountId: any, cartName: any}): Promise<any>;
}
declare module "@salesforce/apex/CartSwitcherController.setPrimaryCart" {
  export default function setPrimaryCart(param: {communityId: any, effectiveAccountId: any, cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/CartSwitcherController.takeOwnership" {
  export default function takeOwnership(param: {communityId: any, effectiveAccountId: any, cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/CartSwitcherController.shareCart" {
  export default function shareCart(param: {communityId: any, effectiveAccountId: any, cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/CartSwitcherController.releaseOwnership" {
  export default function releaseOwnership(param: {communityId: any, effectiveAccountId: any, cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/CartSwitcherController.deleteCart" {
  export default function deleteCart(param: {communityId: any, effectiveAccountId: any, cartId: any}): Promise<any>;
}
