declare module "@salesforce/apex/DynamicBannerController.getUser" {
  export default function getUser(param: {userId: any}): Promise<any>;
}
declare module "@salesforce/apex/DynamicBannerController.getDynamicContentRecords" {
  export default function getDynamicContentRecords(param: {ParamTag: any, ParamContentType: any}): Promise<any>;
}
