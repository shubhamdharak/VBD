declare module "@salesforce/apex/recommendationController.getRecommendations" {
  export default function getRecommendations(param: {recommender: any, anchorValues: any, storeNameValue: any, cookie: any}): Promise<any>;
}
