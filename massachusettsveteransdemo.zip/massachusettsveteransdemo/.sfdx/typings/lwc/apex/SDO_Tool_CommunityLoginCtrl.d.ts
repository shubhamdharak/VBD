declare module "@salesforce/apex/SDO_Tool_CommunityLoginCtrl.getNetworks" {
  export default function getNetworks(param: {recordId: any}): Promise<any>;
}
