({
    // Created by Craig Paterson
    // July 8 2020
    doInit : function(component, event, helper) {
        helper.init(component, event);
    }
})