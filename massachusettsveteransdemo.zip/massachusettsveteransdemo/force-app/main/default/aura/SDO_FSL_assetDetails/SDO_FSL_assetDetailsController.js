({
	doInit : function(component, event, helper) {
		helper.getAsset(component);
	}
})