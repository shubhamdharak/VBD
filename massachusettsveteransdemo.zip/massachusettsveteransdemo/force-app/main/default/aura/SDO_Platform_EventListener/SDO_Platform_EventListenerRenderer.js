({
	 unrender: function (component) {
     	//var myEventHub = component.find('SampleEventListenerHub');
       
        	//myEventHub.disconnectCometd();
     }
})